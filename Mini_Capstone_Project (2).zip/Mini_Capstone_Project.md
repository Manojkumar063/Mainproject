# Database connection 
 


```python
import pymysql
import pandas as pd
import warnings
import matplotlib.pyplot as plt
import numpy as np
# Suppress all warnings
warnings.filterwarnings("ignore")

connection = pymysql.connect(
    host='localhost',
    user='root',
    password='mk2002',
    database='crime_dataa'
)
query = "SELECT*from crimedata;"
df = pd.read_sql(query,connection)

df


```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DR_NO</th>
      <th>Date_Rptd</th>
      <th>DATE_OCC</th>
      <th>AREA_NAME</th>
      <th>Crm_Cd</th>
      <th>Crm_Cd_Desc</th>
      <th>Vict_Age</th>
      <th>Vict_Sex</th>
      <th>Premis_Desc</th>
      <th>Status</th>
      <th>Location</th>
      <th>LAT</th>
      <th>LON</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10304468</td>
      <td>01-08-2020</td>
      <td>01-08-2020</td>
      <td>Southwest</td>
      <td>624</td>
      <td>BATTERY - SIMPLE ASSAULT</td>
      <td>36</td>
      <td>F</td>
      <td>SINGLE FAMILY DWELLING</td>
      <td>AO</td>
      <td>1100 W 39TH PL</td>
      <td>34.01</td>
      <td>-118.30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>190101086</td>
      <td>01-02-2020</td>
      <td>01-01-2020</td>
      <td>Central</td>
      <td>624</td>
      <td>BATTERY - SIMPLE ASSAULT</td>
      <td>25</td>
      <td>M</td>
      <td>SIDEWALK</td>
      <td>IC</td>
      <td>700 S HILL ST</td>
      <td>34.05</td>
      <td>-118.25</td>
    </tr>
    <tr>
      <th>2</th>
      <td>191501505</td>
      <td>01-01-2020</td>
      <td>01-01-2020</td>
      <td>N Hollywood</td>
      <td>745</td>
      <td>VANDALISM - MISDEAMEANOR ($399 OR UNDER)</td>
      <td>76</td>
      <td>F</td>
      <td>MULTI-UNIT DWELLING (APARTMENT, DUPLEX, ETC)</td>
      <td>IC</td>
      <td>5400 CORTEEN PL</td>
      <td>34.17</td>
      <td>-118.40</td>
    </tr>
    <tr>
      <th>3</th>
      <td>191921269</td>
      <td>01-01-2020</td>
      <td>01-01-2020</td>
      <td>Mission</td>
      <td>740</td>
      <td>VANDALISM - FELONY ($400 &amp; OVER, ALL CHURCH VA...</td>
      <td>31</td>
      <td>X</td>
      <td>BEAUTY SUPPLY STORE</td>
      <td>IC</td>
      <td>14400 TITUS ST</td>
      <td>34.22</td>
      <td>-118.45</td>
    </tr>
    <tr>
      <th>4</th>
      <td>200100502</td>
      <td>01-02-2020</td>
      <td>01-02-2020</td>
      <td>Central</td>
      <td>442</td>
      <td>SHOPLIFTING - PETTY THEFT ($950 &amp; UNDER)</td>
      <td>23</td>
      <td>M</td>
      <td>DEPARTMENT STORE</td>
      <td>IC</td>
      <td>700 S FIGUEROA ST</td>
      <td>34.05</td>
      <td>-118.26</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>494</th>
      <td>200106614</td>
      <td>02-07-2020</td>
      <td>02-07-2020</td>
      <td>Central</td>
      <td>624</td>
      <td>BATTERY - SIMPLE ASSAULT</td>
      <td>33</td>
      <td>M</td>
      <td>SIDEWALK</td>
      <td>IC</td>
      <td>2400 ELLENDALE PL</td>
      <td>34.05</td>
      <td>-118.26</td>
    </tr>
    <tr>
      <th>495</th>
      <td>200106615</td>
      <td>02-07-2020</td>
      <td>02-07-2020</td>
      <td>Central</td>
      <td>624</td>
      <td>BATTERY - SIMPLE ASSAULT</td>
      <td>25</td>
      <td>M</td>
      <td>SIDEWALK</td>
      <td>IC</td>
      <td>39TH PL</td>
      <td>34.05</td>
      <td>-118.26</td>
    </tr>
    <tr>
      <th>496</th>
      <td>200106616</td>
      <td>02-07-2020</td>
      <td>02-07-2020</td>
      <td>Central</td>
      <td>624</td>
      <td>BATTERY - SIMPLE ASSAULT</td>
      <td>35</td>
      <td>M</td>
      <td>OTHER STORE</td>
      <td>IC</td>
      <td>2500 W VERNON AV</td>
      <td>34.05</td>
      <td>-118.25</td>
    </tr>
    <tr>
      <th>497</th>
      <td>200106617</td>
      <td>02-07-2020</td>
      <td>01-10-2020</td>
      <td>Central</td>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
      <td>0</td>
      <td>F</td>
      <td>PARKING LOT</td>
      <td>IC</td>
      <td>700 EXPOSITION BL</td>
      <td>34.05</td>
      <td>-118.25</td>
    </tr>
    <tr>
      <th>498</th>
      <td>200106618</td>
      <td>02-07-2020</td>
      <td>02-03-2020</td>
      <td>Central</td>
      <td>745</td>
      <td>VANDALISM - MISDEAMEANOR ($399 OR UNDER)</td>
      <td>72</td>
      <td>M</td>
      <td>VEHICLE, PASSENGER/TRUCK</td>
      <td>IC</td>
      <td>2600 S FIGUEROA ST</td>
      <td>34.05</td>
      <td>-118.24</td>
    </tr>
  </tbody>
</table>
<p>499 rows × 13 columns</p>
</div>



# Data Exploration
--Identify Distinct Crime Codes


```python
query2="SELECT COUNT(DISTINCT crm_cd) as 'MANOJKUMAR' FROM crimedata;"

query="SELECT COUNT(*) as 'TOTALROWS' FROM crimedata;"

df=pd.read_sql(query,connection)
df2=pd.read_sql(query2,connection)
print(df)
df2
    


    

```

       TOTALROWS
    0        499
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MANOJKUMAR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>42</td>
    </tr>
  </tbody>
</table>
</div>



--Distinct crime codes and their descriptions:


```python
query="SELECT DISTINCT crm_cd, crm_cd_desc FROM crimedata"
print("Distinct crime codes and their descriptions:")
df=pd.read_sql(query,connection)
df
```

    Distinct crime codes and their descriptions:
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>crm_cd</th>
      <th>crm_cd_desc</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>624</td>
      <td>BATTERY - SIMPLE ASSAULT</td>
    </tr>
    <tr>
      <th>1</th>
      <td>745</td>
      <td>VANDALISM - MISDEAMEANOR ($399 OR UNDER)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>740</td>
      <td>VANDALISM - FELONY ($400 &amp; OVER, ALL CHURCH VA...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>442</td>
      <td>SHOPLIFTING - PETTY THEFT ($950 &amp; UNDER)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>946</td>
      <td>OTHER MISCELLANEOUS CRIME</td>
    </tr>
    <tr>
      <th>5</th>
      <td>341</td>
      <td>THEFT-GRAND ($950.01 &amp; OVER)EXCPT,GUNS,FOWL,LI...</td>
    </tr>
    <tr>
      <th>6</th>
      <td>330</td>
      <td>BURGLARY FROM VEHICLE</td>
    </tr>
    <tr>
      <th>7</th>
      <td>930</td>
      <td>CRIMINAL THREATS - NO WEAPON DISPLAYED</td>
    </tr>
    <tr>
      <th>8</th>
      <td>648</td>
      <td>ARSON</td>
    </tr>
    <tr>
      <th>9</th>
      <td>354</td>
      <td>THEFT OF IDENTITY</td>
    </tr>
    <tr>
      <th>10</th>
      <td>230</td>
      <td>ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT</td>
    </tr>
    <tr>
      <th>11</th>
      <td>761</td>
      <td>BRANDISH WEAPON</td>
    </tr>
    <tr>
      <th>12</th>
      <td>350</td>
      <td>THEFT, PERSON</td>
    </tr>
    <tr>
      <th>13</th>
      <td>310</td>
      <td>BURGLARY</td>
    </tr>
    <tr>
      <th>14</th>
      <td>480</td>
      <td>BIKE - STOLEN</td>
    </tr>
    <tr>
      <th>15</th>
      <td>623</td>
      <td>BATTERY POLICE (SIMPLE)</td>
    </tr>
    <tr>
      <th>16</th>
      <td>440</td>
      <td>THEFT PLAIN - PETTY ($950 &amp; UNDER)</td>
    </tr>
    <tr>
      <th>17</th>
      <td>510</td>
      <td>VEHICLE - STOLEN</td>
    </tr>
    <tr>
      <th>18</th>
      <td>210</td>
      <td>ROBBERY</td>
    </tr>
    <tr>
      <th>19</th>
      <td>900</td>
      <td>VIOLATION OF COURT ORDER</td>
    </tr>
    <tr>
      <th>20</th>
      <td>888</td>
      <td>TRESPASSING</td>
    </tr>
    <tr>
      <th>21</th>
      <td>420</td>
      <td>THEFT FROM MOTOR VEHICLE - PETTY ($950 &amp; UNDER)</td>
    </tr>
    <tr>
      <th>22</th>
      <td>886</td>
      <td>DISTURBING THE PEACE</td>
    </tr>
    <tr>
      <th>23</th>
      <td>421</td>
      <td>THEFT FROM MOTOR VEHICLE - ATTEMPT</td>
    </tr>
    <tr>
      <th>24</th>
      <td>647</td>
      <td>THROWING OBJECT AT MOVING VEHICLE</td>
    </tr>
    <tr>
      <th>25</th>
      <td>940</td>
      <td>EXTORTION</td>
    </tr>
    <tr>
      <th>26</th>
      <td>662</td>
      <td>BUNCO, GRAND THEFT</td>
    </tr>
    <tr>
      <th>27</th>
      <td>220</td>
      <td>ATTEMPTED ROBBERY</td>
    </tr>
    <tr>
      <th>28</th>
      <td>625</td>
      <td>OTHER ASSAULT</td>
    </tr>
    <tr>
      <th>29</th>
      <td>755</td>
      <td>BOMB SCARE</td>
    </tr>
    <tr>
      <th>30</th>
      <td>649</td>
      <td>DOCUMENT FORGERY / STOLEN FELONY</td>
    </tr>
    <tr>
      <th>31</th>
      <td>901</td>
      <td>VIOLATION OF RESTRAINING ORDER</td>
    </tr>
    <tr>
      <th>32</th>
      <td>320</td>
      <td>BURGLARY, ATTEMPTED</td>
    </tr>
    <tr>
      <th>33</th>
      <td>890</td>
      <td>FAILURE TO YIELD</td>
    </tr>
    <tr>
      <th>34</th>
      <td>351</td>
      <td>PURSE SNATCHING</td>
    </tr>
    <tr>
      <th>35</th>
      <td>956</td>
      <td>LETTERS, LEWD  -  TELEPHONE CALLS, LEWD</td>
    </tr>
    <tr>
      <th>36</th>
      <td>820</td>
      <td>ORAL COPULATION</td>
    </tr>
    <tr>
      <th>37</th>
      <td>812</td>
      <td>CRM AGNST CHLD (13 OR UNDER) (14-15 &amp; SUSP 10 ...</td>
    </tr>
    <tr>
      <th>38</th>
      <td>920</td>
      <td>KIDNAPPING - GRAND ATTEMPT</td>
    </tr>
    <tr>
      <th>39</th>
      <td>850</td>
      <td>INDECENT EXPOSURE</td>
    </tr>
    <tr>
      <th>40</th>
      <td>666</td>
      <td>BUNCO, ATTEMPT</td>
    </tr>
    <tr>
      <th>41</th>
      <td>343</td>
      <td>SHOPLIFTING-GRAND THEFT ($950.01 &amp; OVER)</td>
    </tr>
  </tbody>
</table>
</div>



# Temporal Analysis
--Analyze trends in crime occurrence over time.


```python
query = "SELECT date_occ, COUNT(*) count FROM crimedata GROUP BY date_occ;" 
df = pd.read_sql(query,connection)
print(df.head(10))
print(df.tail(10))
df['date_occ'] = pd.to_datetime(df['date_occ'])
df.set_index('date_occ', inplace=True)
df.plot(kind='line', figsize=(12, 6), legend=False)
plt.title('Crime Trends Over Time')
plt.xlabel('Date')
plt.ylabel('Number of Crimes')
plt.show()
d=df.info()
```

         date_occ  count
    0  01-08-2020     25
    1  01-01-2020     34
    2  01-02-2020     27
    3  01-04-2020     29
    4  01-05-2020     24
    5  01-07-2020     22
    6  09-09-2020      1
    7  12-03-2020      1
    8  02-04-2020     19
    9  02-06-2020     10
          date_occ  count
    51  09-02-2020      1
    52  02-03-2020     20
    53  07-05-2020      2
    54  04-07-2020      1
    55  10-06-2020      1
    56  09-04-2020      1
    57  11-04-2020      1
    58  09-08-2020      1
    59  02-10-2020      1
    60  02-07-2020      6
    


    
![png](output_7_1.png)
    


    <class 'pandas.core.frame.DataFrame'>
    DatetimeIndex: 61 entries, 2020-01-08 to 2020-02-07
    Data columns (total 1 columns):
     #   Column  Non-Null Count  Dtype
    ---  ------  --------------  -----
     0   count   61 non-null     int64
    dtypes: int64(1)
    memory usage: 976.0 bytes
    

# Spatial Analysis


```python
pip install folium
```


```python
import pandas as pd
import folium
from sqlalchemy import create_engine
from IPython.display import display

#Utilize the geographical information (Latitude and Longitude) to perform spatial analysis.

#Visualize crime hotspots on a map.
connection_string = f'mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}'

# Create an SQLAlchemy engine
engine = create_engine(connection_string)

# Query to select LAT and LON from crimedata
query = "SELECT LAT, LON FROM crimedata WHERE LAT IS NOT NULL AND LON IS NOT NULL;"

# Read the data into a pandas DataFrame
df = pd.read_sql(query, engine)

# Check if the DataFrame is empty
if df.empty:
    print("No data retrieved from the database.")
else:
    # Create a map centered around the USA
    m = folium.Map(location=[37.0902, -95.7129], zoom_start=4)

    # Add Markers to the map for each crime location
    for index, row in df.iterrows():
        folium.Marker([row['LAT'], row['LON']], icon=folium.Icon(color='red', icon='info-sign')).add_to(m)

    # Display the map in the notebook
    display(m)
query = "SELECT LAT, LON FROM crimedata WHERE LAT IS NOT NULL AND LON IS NOT NULL;"

# Read the data into a pandas DataFrame
df = pd.read_sql(query, engine)
df.head(10)
```


<div style="width:100%;"><div style="position:relative;width:100%;height:0;padding-bottom:60%;"><span style="color:#565656">Make this Notebook Trusted to load map: File -> Trust Notebook</span><iframe srcdoc="&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;

    &lt;meta http-equiv=&quot;content-type&quot; content=&quot;text/html; charset=UTF-8&quot; /&gt;

        &lt;script&gt;
            L_NO_TOUCH = false;
            L_DISABLE_3D = false;
        &lt;/script&gt;

    &lt;style&gt;html, body {width: 100%;height: 100%;margin: 0;padding: 0;}&lt;/style&gt;
    &lt;style&gt;#map {position:absolute;top:0;bottom:0;right:0;left:0;}&lt;/style&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.9.3/dist/leaflet.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://code.jquery.com/jquery-3.7.1.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js&quot;&gt;&lt;/script&gt;
    &lt;script src=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.js&quot;&gt;&lt;/script&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/leaflet@1.9.3/dist/leaflet.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.0/css/all.min.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdnjs.cloudflare.com/ajax/libs/Leaflet.awesome-markers/2.0.2/leaflet.awesome-markers.css&quot;/&gt;
    &lt;link rel=&quot;stylesheet&quot; href=&quot;https://cdn.jsdelivr.net/gh/python-visualization/folium/folium/templates/leaflet.awesome.rotate.min.css&quot;/&gt;

            &lt;meta name=&quot;viewport&quot; content=&quot;width=device-width,
                initial-scale=1.0, maximum-scale=1.0, user-scalable=no&quot; /&gt;
            &lt;style&gt;
                #map_e02899f4f20b3725efe51d91e237c586 {
                    position: relative;
                    width: 100.0%;
                    height: 100.0%;
                    left: 0.0%;
                    top: 0.0%;
                }
                .leaflet-container { font-size: 1rem; }
            &lt;/style&gt;

&lt;/head&gt;
&lt;body&gt;


            &lt;div class=&quot;folium-map&quot; id=&quot;map_e02899f4f20b3725efe51d91e237c586&quot; &gt;&lt;/div&gt;

&lt;/body&gt;
&lt;script&gt;


            var map_e02899f4f20b3725efe51d91e237c586 = L.map(
                &quot;map_e02899f4f20b3725efe51d91e237c586&quot;,
                {
                    center: [37.0902, -95.7129],
                    crs: L.CRS.EPSG3857,
                    zoom: 4,
                    zoomControl: true,
                    preferCanvas: false,
                }
            );





            var tile_layer_b9f214aaf0cf27cf3e1c08e19fbea598 = L.tileLayer(
                &quot;https://tile.openstreetmap.org/{z}/{x}/{y}.png&quot;,
                {&quot;attribution&quot;: &quot;\u0026copy; \u003ca href=\&quot;https://www.openstreetmap.org/copyright\&quot;\u003eOpenStreetMap\u003c/a\u003e contributors&quot;, &quot;detectRetina&quot;: false, &quot;maxNativeZoom&quot;: 19, &quot;maxZoom&quot;: 19, &quot;minZoom&quot;: 0, &quot;noWrap&quot;: false, &quot;opacity&quot;: 1, &quot;subdomains&quot;: &quot;abc&quot;, &quot;tms&quot;: false}
            );


            tile_layer_b9f214aaf0cf27cf3e1c08e19fbea598.addTo(map_e02899f4f20b3725efe51d91e237c586);


            var marker_33fb5b903f0f1fe6b2e85b59b4ad1037 = L.marker(
                [34.01, -118.3],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_372471d979b6c91107567cec22a7d252 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_33fb5b903f0f1fe6b2e85b59b4ad1037.setIcon(icon_372471d979b6c91107567cec22a7d252);


            var marker_57c5a143a579fb0c39eb49f811fddc7f = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_76138bd10cef70e53a9c946de90ef858 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_57c5a143a579fb0c39eb49f811fddc7f.setIcon(icon_76138bd10cef70e53a9c946de90ef858);


            var marker_f697f401517301cda9bb6e13f2d553fa = L.marker(
                [34.17, -118.4],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b66abfb720dbc75a5e76bbe7c43cca33 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f697f401517301cda9bb6e13f2d553fa.setIcon(icon_b66abfb720dbc75a5e76bbe7c43cca33);


            var marker_a21f1ae17de79c5f0740cbc13c1c312c = L.marker(
                [34.22, -118.45],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_46a65d410b17f59672170e777888efd0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a21f1ae17de79c5f0740cbc13c1c312c.setIcon(icon_46a65d410b17f59672170e777888efd0);


            var marker_c8547f1c2a41718f9bd8db764f28f473 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_991ea5185d5369c38a143f2881577611 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c8547f1c2a41718f9bd8db764f28f473.setIcon(icon_991ea5185d5369c38a143f2881577611);


            var marker_e6368455f7e7af21327283b03f7c7552 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d782fe11c4e9b504530e7ed71a00ed3b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e6368455f7e7af21327283b03f7c7552.setIcon(icon_d782fe11c4e9b504530e7ed71a00ed3b);


            var marker_82f93c5f4685d604d17cbcd15536e633 = L.marker(
                [34.07, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c1f4355e8498f77b1abd9e4df54a0db0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_82f93c5f4685d604d17cbcd15536e633.setIcon(icon_c1f4355e8498f77b1abd9e4df54a0db0);


            var marker_a663483a4a1341e557b464e4356d4b0f = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_81c4e19dbe63ef3c726e83cd09e7f274 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a663483a4a1341e557b464e4356d4b0f.setIcon(icon_81c4e19dbe63ef3c726e83cd09e7f274);


            var marker_45dcc88e390195e22e6879f23b2b963a = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7bf7c65707d8b6fc12a9ebd05b70a7db = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_45dcc88e390195e22e6879f23b2b963a.setIcon(icon_7bf7c65707d8b6fc12a9ebd05b70a7db);


            var marker_577ecb339b2b236df22db1f845a002b8 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_84bf87c19a23a0345a9884ea568cc566 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_577ecb339b2b236df22db1f845a002b8.setIcon(icon_84bf87c19a23a0345a9884ea568cc566);


            var marker_d8b77eeeaf995dfed633079baad5e5f0 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c69766703931441a0edd35d6d2fb9cab = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d8b77eeeaf995dfed633079baad5e5f0.setIcon(icon_c69766703931441a0edd35d6d2fb9cab);


            var marker_c0eb1b09fc281ab59ee264d526ad23ad = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_58125af1c799993f0793b83fc840e5eb = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c0eb1b09fc281ab59ee264d526ad23ad.setIcon(icon_58125af1c799993f0793b83fc840e5eb);


            var marker_ce3f04d24d921a1e3a790708e4e7b112 = L.marker(
                [34.2, -118.43],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_083d061ed9c3294f058edad3bb286568 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ce3f04d24d921a1e3a790708e4e7b112.setIcon(icon_083d061ed9c3294f058edad3bb286568);


            var marker_c4b221b70aac7d0546bb05f9e5e2afd4 = L.marker(
                [34.08, -118.37],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9251e203b3c2c58f9875697a18e3fefa = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c4b221b70aac7d0546bb05f9e5e2afd4.setIcon(icon_9251e203b3c2c58f9875697a18e3fefa);


            var marker_cdd02f2b1f80b396b3b8cf18232900fe = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ae23adc9f961cd84ab08b85f6a453bd8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cdd02f2b1f80b396b3b8cf18232900fe.setIcon(icon_ae23adc9f961cd84ab08b85f6a453bd8);


            var marker_77c0205eb325bc5e19622d367005e91a = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_774fa13ebbb6e941139ea2911ca8d034 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_77c0205eb325bc5e19622d367005e91a.setIcon(icon_774fa13ebbb6e941139ea2911ca8d034);


            var marker_63cfa57267b9f5b9873696bacaa39800 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a48d8068351cddca91dfd3323022343e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_63cfa57267b9f5b9873696bacaa39800.setIcon(icon_a48d8068351cddca91dfd3323022343e);


            var marker_6d989a22787ba669634ce59c4b63cd97 = L.marker(
                [34.07, -118.28],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2a74e082e1f8f3a7c2a73777065e595e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6d989a22787ba669634ce59c4b63cd97.setIcon(icon_2a74e082e1f8f3a7c2a73777065e595e);


            var marker_ea70af013058cd06b14de9fb0e11c524 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8fc4c263cbb65792d88710838a5dbcf5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ea70af013058cd06b14de9fb0e11c524.setIcon(icon_8fc4c263cbb65792d88710838a5dbcf5);


            var marker_8ae4909f5a3a928271ffc850b0fc8d4a = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f44347ea39726bde61c536042de2851d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8ae4909f5a3a928271ffc850b0fc8d4a.setIcon(icon_f44347ea39726bde61c536042de2851d);


            var marker_cd1740589dea751002504b84e6f9e52d = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1de1eb3f630d4a7e0478dadb6f7ae05b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cd1740589dea751002504b84e6f9e52d.setIcon(icon_1de1eb3f630d4a7e0478dadb6f7ae05b);


            var marker_abf1956483b47cccb74512965f72e0ed = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9a22aa4a5d075898519e5afbd9ec370e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_abf1956483b47cccb74512965f72e0ed.setIcon(icon_9a22aa4a5d075898519e5afbd9ec370e);


            var marker_d199588a1d19289a00c27a07e9706237 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2f2d10382893535dd6b35a7f7191262f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d199588a1d19289a00c27a07e9706237.setIcon(icon_2f2d10382893535dd6b35a7f7191262f);


            var marker_822b28b4df301aa5cdae84f8abe8bf0e = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2eb8f02fefc2382bcd4004d05827b9aa = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_822b28b4df301aa5cdae84f8abe8bf0e.setIcon(icon_2eb8f02fefc2382bcd4004d05827b9aa);


            var marker_d34d1504dd963047ced29c49bbf63d67 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_89409e02d0cc8f366793f50080f0dbf9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d34d1504dd963047ced29c49bbf63d67.setIcon(icon_89409e02d0cc8f366793f50080f0dbf9);


            var marker_d4bb5d35077648f1a071997bb7e56e8a = L.marker(
                [34.03, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d261b3056314f3c44ad17531218433e8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d4bb5d35077648f1a071997bb7e56e8a.setIcon(icon_d261b3056314f3c44ad17531218433e8);


            var marker_a5e41f50d1172a61224691cca22adbea = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_add26eb38839a67c6b8d6b42be9e6a45 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a5e41f50d1172a61224691cca22adbea.setIcon(icon_add26eb38839a67c6b8d6b42be9e6a45);


            var marker_307af0fc40dffe866b429dba9ba429ee = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b2ccf752ebe634fb8135a52b410cf7bb = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_307af0fc40dffe866b429dba9ba429ee.setIcon(icon_b2ccf752ebe634fb8135a52b410cf7bb);


            var marker_c08e6db8db648ea46020e70b06c93c03 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_81974b2c55c97c373dacb00d9e70a364 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c08e6db8db648ea46020e70b06c93c03.setIcon(icon_81974b2c55c97c373dacb00d9e70a364);


            var marker_24a295904ffe8d469aba97d8cca9c316 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_78aa180b7f9cf68cfc5ec3a908dc8d74 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_24a295904ffe8d469aba97d8cca9c316.setIcon(icon_78aa180b7f9cf68cfc5ec3a908dc8d74);


            var marker_d62ac0e0a2a408795229ecc789359107 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_86609cc37b0c4594e8d63b69353336c3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d62ac0e0a2a408795229ecc789359107.setIcon(icon_86609cc37b0c4594e8d63b69353336c3);


            var marker_7f2c8b6d65e0d264857ce6f6be165f5b = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_51d91bb3c11ee9c871c0e66f8c4c5084 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7f2c8b6d65e0d264857ce6f6be165f5b.setIcon(icon_51d91bb3c11ee9c871c0e66f8c4c5084);


            var marker_d2c2fad8315bb4ad311c750d5513db72 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0c3f32cb8a99009655eb30e95beb1cd0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d2c2fad8315bb4ad311c750d5513db72.setIcon(icon_0c3f32cb8a99009655eb30e95beb1cd0);


            var marker_23d3b4286b6c56b6a7eb8dc0148efb02 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7cafd7eeb98fea058b3b902627bd886f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_23d3b4286b6c56b6a7eb8dc0148efb02.setIcon(icon_7cafd7eeb98fea058b3b902627bd886f);


            var marker_4e3b1f6f92da732fbcb4cacd18585cb8 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7f9f483292f4ea90ed7d86b30b48fecc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4e3b1f6f92da732fbcb4cacd18585cb8.setIcon(icon_7f9f483292f4ea90ed7d86b30b48fecc);


            var marker_9666cb58bc599122b5b36b4c498bb834 = L.marker(
                [34.06, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_56e5d33a61b4bbac7a516b516c55c975 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9666cb58bc599122b5b36b4c498bb834.setIcon(icon_56e5d33a61b4bbac7a516b516c55c975);


            var marker_d13155b03510fae6d2df2aa80a94e178 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_fcc143a52ab47e63258b23e9d5596219 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d13155b03510fae6d2df2aa80a94e178.setIcon(icon_fcc143a52ab47e63258b23e9d5596219);


            var marker_2cea1a36ac3a25727dc8a1c8a9c4acc4 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_80688f62c91ea14828995dbdba2a2bc1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2cea1a36ac3a25727dc8a1c8a9c4acc4.setIcon(icon_80688f62c91ea14828995dbdba2a2bc1);


            var marker_15b355352acbafd1755d3291f87a12ef = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6cf043ed8626f62ecff68712f4a800e2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_15b355352acbafd1755d3291f87a12ef.setIcon(icon_6cf043ed8626f62ecff68712f4a800e2);


            var marker_832f866e2a8ba6b13235ac891938cede = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_54d7398ba57d2b82c8289ea57ac3294a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_832f866e2a8ba6b13235ac891938cede.setIcon(icon_54d7398ba57d2b82c8289ea57ac3294a);


            var marker_bc6f254d679fa384ce1548e4bc768403 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9a382669fce04e827edbcca786e4dd39 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_bc6f254d679fa384ce1548e4bc768403.setIcon(icon_9a382669fce04e827edbcca786e4dd39);


            var marker_960c5bee77471d9d1beea04461dab6f5 = L.marker(
                [34.03, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3b3fe84fd39e043fb425fd20f555fe23 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_960c5bee77471d9d1beea04461dab6f5.setIcon(icon_3b3fe84fd39e043fb425fd20f555fe23);


            var marker_ba72447f5f2db32c052a2c3df685b506 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c3ee90f9a323e7df73324b96ed70a592 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ba72447f5f2db32c052a2c3df685b506.setIcon(icon_c3ee90f9a323e7df73324b96ed70a592);


            var marker_b515418f1222e9c4a44308e8215d6fb7 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7d22ee0d7bcb9fd3a1c756de79fea4f4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b515418f1222e9c4a44308e8215d6fb7.setIcon(icon_7d22ee0d7bcb9fd3a1c756de79fea4f4);


            var marker_6918bb95ca682c285e8a57800ae80f28 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_adae0a754869f45562d735b0a647548e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6918bb95ca682c285e8a57800ae80f28.setIcon(icon_adae0a754869f45562d735b0a647548e);


            var marker_a55673ed6226a5b25ab87ce8e89b7136 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e808fabea596d85aabfe50bf22ecf5c1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a55673ed6226a5b25ab87ce8e89b7136.setIcon(icon_e808fabea596d85aabfe50bf22ecf5c1);


            var marker_7f441d95d6677705462486a96163cadd = L.marker(
                [34.18, -118.45],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_06ba2db16d2ec1a1d2db712f29d13a23 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7f441d95d6677705462486a96163cadd.setIcon(icon_06ba2db16d2ec1a1d2db712f29d13a23);


            var marker_c47f65929f4af901af30c39626b5349f = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2a9d6c506ef024cf12243e51c5f70b1e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c47f65929f4af901af30c39626b5349f.setIcon(icon_2a9d6c506ef024cf12243e51c5f70b1e);


            var marker_6649f65534ca8210378fa82e64616dda = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ae32d4b324af3c95b071803ea75bafb5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6649f65534ca8210378fa82e64616dda.setIcon(icon_ae32d4b324af3c95b071803ea75bafb5);


            var marker_f955d6e1b52a1c9c01128772c10ff452 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_192a261eee5ae6aa5749c3762877bdca = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f955d6e1b52a1c9c01128772c10ff452.setIcon(icon_192a261eee5ae6aa5749c3762877bdca);


            var marker_ea5f567c104cb2f5d2d4de00401a3c7c = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_762dc3c0dd7c7522c0efe0ff162b89d4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ea5f567c104cb2f5d2d4de00401a3c7c.setIcon(icon_762dc3c0dd7c7522c0efe0ff162b89d4);


            var marker_6e190c7b5e39f6fb0c49b6ab0dcd6f22 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d96810d8d15a7210b0657b412dc54e58 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6e190c7b5e39f6fb0c49b6ab0dcd6f22.setIcon(icon_d96810d8d15a7210b0657b412dc54e58);


            var marker_e5aac87e124a7b4ddc7b3e1824f45e62 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_318cb9cb94bff110933ef46de825e96e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e5aac87e124a7b4ddc7b3e1824f45e62.setIcon(icon_318cb9cb94bff110933ef46de825e96e);


            var marker_6680e8ab5f85e2e5bd324c8abbc6010f = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7cde408902e4e0bc65ee449fe45662fc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6680e8ab5f85e2e5bd324c8abbc6010f.setIcon(icon_7cde408902e4e0bc65ee449fe45662fc);


            var marker_58496485965ef4fd2653d3144b954005 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_533ba6d98d2b8e231e8a814f042c1b7d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_58496485965ef4fd2653d3144b954005.setIcon(icon_533ba6d98d2b8e231e8a814f042c1b7d);


            var marker_209c5a948d131e92d2ca62108ebbb167 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_58a5565e6ef5a95fce9c2bdf4f67f5e3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_209c5a948d131e92d2ca62108ebbb167.setIcon(icon_58a5565e6ef5a95fce9c2bdf4f67f5e3);


            var marker_fc3a0b1c13ae3930166564ebf6558db0 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_faa32a58b530b6cfa56d17bb2cc11866 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_fc3a0b1c13ae3930166564ebf6558db0.setIcon(icon_faa32a58b530b6cfa56d17bb2cc11866);


            var marker_14c72f884bfd750cd65931f1a6eecc5d = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_94c44a169a9ca9c6117e287ea9503645 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_14c72f884bfd750cd65931f1a6eecc5d.setIcon(icon_94c44a169a9ca9c6117e287ea9503645);


            var marker_ec4dd08ab39c0ee5962e272d0834a604 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7130343f83fc6a20f6a7f6c801bb6942 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ec4dd08ab39c0ee5962e272d0834a604.setIcon(icon_7130343f83fc6a20f6a7f6c801bb6942);


            var marker_9244aa8de7f6912d6ae118dde9ceaf37 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8c439ec7d12459d5c49deb0a43e9aa84 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9244aa8de7f6912d6ae118dde9ceaf37.setIcon(icon_8c439ec7d12459d5c49deb0a43e9aa84);


            var marker_493a66b652349793abe843064b465802 = L.marker(
                [33.81, -118.31],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c184b0bc8ad6dca2d15e331cba655d5e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_493a66b652349793abe843064b465802.setIcon(icon_c184b0bc8ad6dca2d15e331cba655d5e);


            var marker_655ae74557e42e718d5553273e3295b5 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ae496b99b613b0350122f2b1f2f77795 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_655ae74557e42e718d5553273e3295b5.setIcon(icon_ae496b99b613b0350122f2b1f2f77795);


            var marker_bfa31c1d34edff585dd2e721bfa76969 = L.marker(
                [34.01, -118.45],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0a7f95ad890b7095572e943b849e7dd5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_bfa31c1d34edff585dd2e721bfa76969.setIcon(icon_0a7f95ad890b7095572e943b849e7dd5);


            var marker_b5ce9c614ffa943630c0d1346f3490bb = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8aed7fba2e5437d36e2121e452d00b54 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b5ce9c614ffa943630c0d1346f3490bb.setIcon(icon_8aed7fba2e5437d36e2121e452d00b54);


            var marker_792dce5e19949cba1456abecb904193b = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9d9f345da17d7c0f1d75884473965547 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_792dce5e19949cba1456abecb904193b.setIcon(icon_9d9f345da17d7c0f1d75884473965547);


            var marker_5510cfaf9773ac31f9dd32ad6718f5af = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5a9554c0d2c057a882f7bf22c300b6b9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5510cfaf9773ac31f9dd32ad6718f5af.setIcon(icon_5a9554c0d2c057a882f7bf22c300b6b9);


            var marker_2c496ecb4ad1da8a90a539113109b162 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cbf073db4c625241eb4f3eb77b07b814 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2c496ecb4ad1da8a90a539113109b162.setIcon(icon_cbf073db4c625241eb4f3eb77b07b814);


            var marker_aafe4d64ff3507605aa8b8625548c0b5 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_077d9125beb419021277794b0b036ece = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_aafe4d64ff3507605aa8b8625548c0b5.setIcon(icon_077d9125beb419021277794b0b036ece);


            var marker_e4ecfcc29f6a8e692fd18a65b8eb41fc = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_de49d22b7aa1d107f96f1768f3cc4c51 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e4ecfcc29f6a8e692fd18a65b8eb41fc.setIcon(icon_de49d22b7aa1d107f96f1768f3cc4c51);


            var marker_013e86c0747f627b081cd2deb4e4bdc2 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b7e2dae8995525993dda86939f16e05c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_013e86c0747f627b081cd2deb4e4bdc2.setIcon(icon_b7e2dae8995525993dda86939f16e05c);


            var marker_770fab9d14b40a55e9615772e1789f3e = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7375d78137af5439915884ff957481c4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_770fab9d14b40a55e9615772e1789f3e.setIcon(icon_7375d78137af5439915884ff957481c4);


            var marker_46334c114481d7c492f03af605487a1a = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_800e9dde7849adf0b3dd5441fb66b01c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_46334c114481d7c492f03af605487a1a.setIcon(icon_800e9dde7849adf0b3dd5441fb66b01c);


            var marker_0caa2a06f233e7e5a200d3f42e307e77 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_77653552ae73eefbc339545d0dde66bb = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0caa2a06f233e7e5a200d3f42e307e77.setIcon(icon_77653552ae73eefbc339545d0dde66bb);


            var marker_0df2dd4148ac0e909b207cac785b442e = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8a9a7d3ab0398204fe3c625d012fd479 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0df2dd4148ac0e909b207cac785b442e.setIcon(icon_8a9a7d3ab0398204fe3c625d012fd479);


            var marker_3b7a7baccc248adad6a590d06378d797 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2d317b5f5c2c1ccf3aad3223004faffc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3b7a7baccc248adad6a590d06378d797.setIcon(icon_2d317b5f5c2c1ccf3aad3223004faffc);


            var marker_5091271bfd51f43195c79da5a8011cae = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d9df4ae85b66cbc5da30741df03cee19 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5091271bfd51f43195c79da5a8011cae.setIcon(icon_d9df4ae85b66cbc5da30741df03cee19);


            var marker_5453323b92b08f73abcd3c4c58805434 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_825915dd912c6bd762d5b27dd0c54353 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5453323b92b08f73abcd3c4c58805434.setIcon(icon_825915dd912c6bd762d5b27dd0c54353);


            var marker_95904f8dc4e5586c1bcd20efc6434d2b = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_603c96b417058ac69d2fe56bc9b21f2f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_95904f8dc4e5586c1bcd20efc6434d2b.setIcon(icon_603c96b417058ac69d2fe56bc9b21f2f);


            var marker_87de49f377e5bd243376766075feb944 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a68d7bd54160f82ca07187ca6a671127 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_87de49f377e5bd243376766075feb944.setIcon(icon_a68d7bd54160f82ca07187ca6a671127);


            var marker_b8d6e3a92b8a61a07164d85d75049c2a = L.marker(
                [34.04, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3a4d0b0aa01fdd9a37ab33922fccc101 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b8d6e3a92b8a61a07164d85d75049c2a.setIcon(icon_3a4d0b0aa01fdd9a37ab33922fccc101);


            var marker_fbacfbb323172735145aaa07097486f2 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5f8bda48a75afa1f5613f24af8a7cc07 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_fbacfbb323172735145aaa07097486f2.setIcon(icon_5f8bda48a75afa1f5613f24af8a7cc07);


            var marker_c20489d6fb47b83811ef57b6503c8731 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_792903d9fdb1004eedf3a948fbfec099 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c20489d6fb47b83811ef57b6503c8731.setIcon(icon_792903d9fdb1004eedf3a948fbfec099);


            var marker_971143d7517ceddbd65b6826d20ca5e7 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1ec1d0177f86a863fdfa087a767c8146 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_971143d7517ceddbd65b6826d20ca5e7.setIcon(icon_1ec1d0177f86a863fdfa087a767c8146);


            var marker_ea2674744d681e7f3e02b449b9f2218a = L.marker(
                [34.08, -118.22],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0dfd161663800b4ecdfae4940a4770f4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ea2674744d681e7f3e02b449b9f2218a.setIcon(icon_0dfd161663800b4ecdfae4940a4770f4);


            var marker_715529a19727b91c6938454abe836665 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f895ae04d7dcc0bad1231be6dc7adbe3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_715529a19727b91c6938454abe836665.setIcon(icon_f895ae04d7dcc0bad1231be6dc7adbe3);


            var marker_4a0745a4eef3cec8ec3452ebb663ac16 = L.marker(
                [34.01, -118.3],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_11e92bbbe442325df57bf3ac6a507488 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4a0745a4eef3cec8ec3452ebb663ac16.setIcon(icon_11e92bbbe442325df57bf3ac6a507488);


            var marker_c916ddd6853f2b60b9ebb441f92f814e = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_efe3ee1b04cb60cbe9089a4c8943f2f9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c916ddd6853f2b60b9ebb441f92f814e.setIcon(icon_efe3ee1b04cb60cbe9089a4c8943f2f9);


            var marker_df910cddc5a330de0149d3204108bca7 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_67d32f32890810bcf0c480b287c61cf7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_df910cddc5a330de0149d3204108bca7.setIcon(icon_67d32f32890810bcf0c480b287c61cf7);


            var marker_f3abc38f77632b7f06cc2971c7c79906 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_109871ec792c5daa358e12c76b0cec80 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f3abc38f77632b7f06cc2971c7c79906.setIcon(icon_109871ec792c5daa358e12c76b0cec80);


            var marker_4505fcd1aa3e535f2af3ade54816e323 = L.marker(
                [34.06, -118.38],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9c5ef6cdb14a951eca70e327607dd259 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4505fcd1aa3e535f2af3ade54816e323.setIcon(icon_9c5ef6cdb14a951eca70e327607dd259);


            var marker_394b2705e363e91f6a2d16be7b4306ee = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_88ada21a18b3ba51d047000eeccb6836 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_394b2705e363e91f6a2d16be7b4306ee.setIcon(icon_88ada21a18b3ba51d047000eeccb6836);


            var marker_963e2980711b1fb429a87790a8dba2ff = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7b8c8fbe8a940a82442edfd5a3e08e21 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_963e2980711b1fb429a87790a8dba2ff.setIcon(icon_7b8c8fbe8a940a82442edfd5a3e08e21);


            var marker_c688faa5cfab1cc4f579355bfd12fa2f = L.marker(
                [34.04, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0c1d065901ce87a424453773fb726e5a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c688faa5cfab1cc4f579355bfd12fa2f.setIcon(icon_0c1d065901ce87a424453773fb726e5a);


            var marker_54f89a7097d772d1ad5dd1c8c8e0e017 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_fda2ccdc9204c29fe089b5245e420515 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_54f89a7097d772d1ad5dd1c8c8e0e017.setIcon(icon_fda2ccdc9204c29fe089b5245e420515);


            var marker_fa2d06c495914246ee247d87582d4c07 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_074a0a5ae6b6de3416925170b6be8220 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_fa2d06c495914246ee247d87582d4c07.setIcon(icon_074a0a5ae6b6de3416925170b6be8220);


            var marker_6c9424606a0b9fa05a6aba4992dcd61f = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e37a02097e872aa7dbf583cca3aebc5f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6c9424606a0b9fa05a6aba4992dcd61f.setIcon(icon_e37a02097e872aa7dbf583cca3aebc5f);


            var marker_d3736836aa33d6c7d3eccbdfa42f8035 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_44a28acb61fc7575576ba7564c46b311 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d3736836aa33d6c7d3eccbdfa42f8035.setIcon(icon_44a28acb61fc7575576ba7564c46b311);


            var marker_9946f24fe2e82b49fbead8c4505de440 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7fde08c21e0ad8cfdaf8dc680758fb22 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9946f24fe2e82b49fbead8c4505de440.setIcon(icon_7fde08c21e0ad8cfdaf8dc680758fb22);


            var marker_1fb268d7c67d01ba0cac4da9cfd28647 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_99c71029f2e14a2b195fb3e29cba1caf = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_1fb268d7c67d01ba0cac4da9cfd28647.setIcon(icon_99c71029f2e14a2b195fb3e29cba1caf);


            var marker_5699e14790ffbf69859a1644e5a290b5 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2c25cfe1a57735b4fa3816ed474671d2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5699e14790ffbf69859a1644e5a290b5.setIcon(icon_2c25cfe1a57735b4fa3816ed474671d2);


            var marker_c34c7bbbad15a9b652ef7c59ddec5dbd = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9d45601c47ff087a4d8fb8bdb2131bf1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c34c7bbbad15a9b652ef7c59ddec5dbd.setIcon(icon_9d45601c47ff087a4d8fb8bdb2131bf1);


            var marker_375565a85c56e7fbc02a1cdad61faf55 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3e4811f798c960339d770b9b87b18808 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_375565a85c56e7fbc02a1cdad61faf55.setIcon(icon_3e4811f798c960339d770b9b87b18808);


            var marker_c680a800887677ad043daefd35ae9697 = L.marker(
                [34.07, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c61fd0235c9a913d8f584dec6ee46d0f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c680a800887677ad043daefd35ae9697.setIcon(icon_c61fd0235c9a913d8f584dec6ee46d0f);


            var marker_18fe6554429ced263c70041962eaec00 = L.marker(
                [34.07, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2281615921ee1e593905992df13ae71d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_18fe6554429ced263c70041962eaec00.setIcon(icon_2281615921ee1e593905992df13ae71d);


            var marker_ba65104ef172918f9a350cc5b80e0f97 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9dfe7920c4adc22180f16b593cdd390d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ba65104ef172918f9a350cc5b80e0f97.setIcon(icon_9dfe7920c4adc22180f16b593cdd390d);


            var marker_8db0d38f93f104a4db2a203cf2a9cf41 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9847198e45294bf36d8bd1646aacab27 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8db0d38f93f104a4db2a203cf2a9cf41.setIcon(icon_9847198e45294bf36d8bd1646aacab27);


            var marker_add74b2b3306c19ee2d3321a0d4a2fe3 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ad2cf1974ce191b853968a13ce15650d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_add74b2b3306c19ee2d3321a0d4a2fe3.setIcon(icon_ad2cf1974ce191b853968a13ce15650d);


            var marker_cff8138ed7281821a520377e4797bf12 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_dbbc64635feb7fc3569418d864b7fd1f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cff8138ed7281821a520377e4797bf12.setIcon(icon_dbbc64635feb7fc3569418d864b7fd1f);


            var marker_a1e8365bb61e213fe77273aa282cccfb = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_488c28c5c19aa772f4596e42589d66d9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a1e8365bb61e213fe77273aa282cccfb.setIcon(icon_488c28c5c19aa772f4596e42589d66d9);


            var marker_0f52a01fc7c602142564422f4979f5ab = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_979de050a082e3564566434feabc1876 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0f52a01fc7c602142564422f4979f5ab.setIcon(icon_979de050a082e3564566434feabc1876);


            var marker_b53494a24f8a43e549754c7acd1296f5 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d40766a6aa97b47bd3eca60587921cd5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b53494a24f8a43e549754c7acd1296f5.setIcon(icon_d40766a6aa97b47bd3eca60587921cd5);


            var marker_b823525a9648a354f78e79d3bf521f06 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_76adf800a67ba0daad7c94b7b27d0427 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b823525a9648a354f78e79d3bf521f06.setIcon(icon_76adf800a67ba0daad7c94b7b27d0427);


            var marker_9ab7ec391c9602b86d98f4ae61204045 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a65f23e948b62e25a9b5f5c2a21cf355 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9ab7ec391c9602b86d98f4ae61204045.setIcon(icon_a65f23e948b62e25a9b5f5c2a21cf355);


            var marker_b520247b047ab88eb1b012a41e31d82e = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1d33b60d35d4d9a578a498135bae497b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b520247b047ab88eb1b012a41e31d82e.setIcon(icon_1d33b60d35d4d9a578a498135bae497b);


            var marker_415c32e09830e212f030dfdc9e1b6ae9 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b69565e93a53362f645879af3d0dc038 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_415c32e09830e212f030dfdc9e1b6ae9.setIcon(icon_b69565e93a53362f645879af3d0dc038);


            var marker_d819d0e8c8ddd1011ec897b2e907c5db = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_888e8ddb7aca89c65cf7cae3e5b9bc82 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d819d0e8c8ddd1011ec897b2e907c5db.setIcon(icon_888e8ddb7aca89c65cf7cae3e5b9bc82);


            var marker_3ee899aa73aa8beda0e1698e38bbae42 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_07029b6af3734bf8f366c3bd069330c5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3ee899aa73aa8beda0e1698e38bbae42.setIcon(icon_07029b6af3734bf8f366c3bd069330c5);


            var marker_8a584fe48fb256feb999c1a8c23badcc = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_469b3a345498b3d29a2b11e75a22b0b1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8a584fe48fb256feb999c1a8c23badcc.setIcon(icon_469b3a345498b3d29a2b11e75a22b0b1);


            var marker_a3047e50d40c18ad17b365339223922f = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ec11f4f934bc90314fc5820c11144a96 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a3047e50d40c18ad17b365339223922f.setIcon(icon_ec11f4f934bc90314fc5820c11144a96);


            var marker_971d777ab30035fd407ab7d590e7b737 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_eca81ed4fb5c84ecc07aed0b8508cc77 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_971d777ab30035fd407ab7d590e7b737.setIcon(icon_eca81ed4fb5c84ecc07aed0b8508cc77);


            var marker_12319f55784a7e631b0842f4e8fd0bf0 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_46da3a35b764c7706f1a80f3442d3604 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_12319f55784a7e631b0842f4e8fd0bf0.setIcon(icon_46da3a35b764c7706f1a80f3442d3604);


            var marker_a826deb6aa2434a9657f1bed50411973 = L.marker(
                [34.04, -118.21],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a0c3a54a6c022fab1428a2fd15087268 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a826deb6aa2434a9657f1bed50411973.setIcon(icon_a0c3a54a6c022fab1428a2fd15087268);


            var marker_c09a4853a3f5556bff33d3c03dd9ac4b = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b538355ded5d590563be0cb232621fc4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c09a4853a3f5556bff33d3c03dd9ac4b.setIcon(icon_b538355ded5d590563be0cb232621fc4);


            var marker_5f43c95c4321f6cf1954533954fa755d = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_867012eeb5e825c22ac91fe480ae0454 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5f43c95c4321f6cf1954533954fa755d.setIcon(icon_867012eeb5e825c22ac91fe480ae0454);


            var marker_9018dcd859977342291ed2609da6f364 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1f57d80b51efca79113a460ad7b44afd = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9018dcd859977342291ed2609da6f364.setIcon(icon_1f57d80b51efca79113a460ad7b44afd);


            var marker_e8de69408c6c53ed9f9b6f0cf6c5e0c8 = L.marker(
                [34.03, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_862c33e9c5e94e77d534e512777c6920 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e8de69408c6c53ed9f9b6f0cf6c5e0c8.setIcon(icon_862c33e9c5e94e77d534e512777c6920);


            var marker_8b910c50c92a9c30865093ce27a7ab87 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4b047b0727e5ed43df0f0c5410ea97c3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8b910c50c92a9c30865093ce27a7ab87.setIcon(icon_4b047b0727e5ed43df0f0c5410ea97c3);


            var marker_9eb95229b9a7968b98d3edf89bed3d51 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b26e0c03df9372f59b8dc7012409543d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9eb95229b9a7968b98d3edf89bed3d51.setIcon(icon_b26e0c03df9372f59b8dc7012409543d);


            var marker_7e0640a3187eba36238d6adb8b357802 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f68d575d98bbb1587cb3f4f72b0e4446 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7e0640a3187eba36238d6adb8b357802.setIcon(icon_f68d575d98bbb1587cb3f4f72b0e4446);


            var marker_ecdb8046e2a851844218c75dadbc3c88 = L.marker(
                [34.11, -118.42],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5acded36dc6d673a20a9cbe52d87343f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ecdb8046e2a851844218c75dadbc3c88.setIcon(icon_5acded36dc6d673a20a9cbe52d87343f);


            var marker_5a18bece6d9338e9f4a1cadce7d8be6a = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6e66481e9bf431202a797f1455fe7fe8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5a18bece6d9338e9f4a1cadce7d8be6a.setIcon(icon_6e66481e9bf431202a797f1455fe7fe8);


            var marker_5425a44caabb4ad0c1c9bb5a3feba57a = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b7ed0da7f76c169fc86904b3e81fb67c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5425a44caabb4ad0c1c9bb5a3feba57a.setIcon(icon_b7ed0da7f76c169fc86904b3e81fb67c);


            var marker_824af80881a08109bbb2da69a506957b = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_99b8789b0b49b22a92b6845e54643f59 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_824af80881a08109bbb2da69a506957b.setIcon(icon_99b8789b0b49b22a92b6845e54643f59);


            var marker_08cb36a616b2b366edea4e4927d1638d = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8487ba26c81174099787c6f86b71f0a7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_08cb36a616b2b366edea4e4927d1638d.setIcon(icon_8487ba26c81174099787c6f86b71f0a7);


            var marker_9847d0befc2480e5b0bfc4f5cd7377f0 = L.marker(
                [34.04, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e7909ba4632fb57786ceb523b2377897 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9847d0befc2480e5b0bfc4f5cd7377f0.setIcon(icon_e7909ba4632fb57786ceb523b2377897);


            var marker_52cc83f4ed051e6925eaf637b0fc03d6 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9bf4025593daac7b1e18b6ed717471bd = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_52cc83f4ed051e6925eaf637b0fc03d6.setIcon(icon_9bf4025593daac7b1e18b6ed717471bd);


            var marker_2a38c4760c73561dce2315d4ed9c71b8 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_65874b059a8f46956e1ee9a1e4597db3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2a38c4760c73561dce2315d4ed9c71b8.setIcon(icon_65874b059a8f46956e1ee9a1e4597db3);


            var marker_d9b8d718c6beb0660ac11623eecc810e = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_19ac56cd23a942ff014f53d1e1abc62c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d9b8d718c6beb0660ac11623eecc810e.setIcon(icon_19ac56cd23a942ff014f53d1e1abc62c);


            var marker_519fac92aacf3fdaf1a909685a72b3af = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1424fd22d156986841d400beca36dac6 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_519fac92aacf3fdaf1a909685a72b3af.setIcon(icon_1424fd22d156986841d400beca36dac6);


            var marker_702da1b98eaf2a78cb27d1611dd70812 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_16c42a19a05fb1aedc3ff98855a675c2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_702da1b98eaf2a78cb27d1611dd70812.setIcon(icon_16c42a19a05fb1aedc3ff98855a675c2);


            var marker_06aa6b301bf7145345678c0e83ebb74b = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a0d0dfa6a4803214ad2dddaed04bd439 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_06aa6b301bf7145345678c0e83ebb74b.setIcon(icon_a0d0dfa6a4803214ad2dddaed04bd439);


            var marker_457de0c72c440d8f47336f53fb21bb48 = L.marker(
                [34.06, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_02b40dd8da78b0d6e848f0149302188c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_457de0c72c440d8f47336f53fb21bb48.setIcon(icon_02b40dd8da78b0d6e848f0149302188c);


            var marker_5ed3141f90939f350cb5132a3f6177d2 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_57f5c9bd2ed31f654b48489f0d9cd427 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5ed3141f90939f350cb5132a3f6177d2.setIcon(icon_57f5c9bd2ed31f654b48489f0d9cd427);


            var marker_884f5bc044ce5485b0b56d6fa602d848 = L.marker(
                [34.03, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_66dda74cce13e157e388bf13278b09ab = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_884f5bc044ce5485b0b56d6fa602d848.setIcon(icon_66dda74cce13e157e388bf13278b09ab);


            var marker_54b6afc4aa0e1ac0bee436b5bcef3a0d = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_72f7e57bdce8b651147dc0ab089ddb18 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_54b6afc4aa0e1ac0bee436b5bcef3a0d.setIcon(icon_72f7e57bdce8b651147dc0ab089ddb18);


            var marker_58e01505c73356ef6d1fe1a4b5055d0b = L.marker(
                [34.12, -118.19],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_94ba0461e8323589e6ab8e43d08690f0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_58e01505c73356ef6d1fe1a4b5055d0b.setIcon(icon_94ba0461e8323589e6ab8e43d08690f0);


            var marker_bddd246e87a2ce38d8558f2547fe1d0c = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_70bce069c1d92ff90b2ae127fb87ff48 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_bddd246e87a2ce38d8558f2547fe1d0c.setIcon(icon_70bce069c1d92ff90b2ae127fb87ff48);


            var marker_ed97f666dc42b23e54cfad47327dd409 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_732650fc049c66008024d10e3068dbcb = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ed97f666dc42b23e54cfad47327dd409.setIcon(icon_732650fc049c66008024d10e3068dbcb);


            var marker_ed87db81d7aa8272b52a77d66889eda6 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2da213a8af8be6ccd6f8f37ed6ba78ba = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ed87db81d7aa8272b52a77d66889eda6.setIcon(icon_2da213a8af8be6ccd6f8f37ed6ba78ba);


            var marker_1243f0a563de5423720a32208001fd21 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_db64f9508974df7a321042f40d1e6c48 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_1243f0a563de5423720a32208001fd21.setIcon(icon_db64f9508974df7a321042f40d1e6c48);


            var marker_25637bb14d655c05cb5eb742262475e8 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_90641ef0e15b7f1cf955fa8df1c08db9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_25637bb14d655c05cb5eb742262475e8.setIcon(icon_90641ef0e15b7f1cf955fa8df1c08db9);


            var marker_5cc3c3d5e375d731a88b40b8c45547b0 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2ff133bce250e0bead869a09ca90075c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5cc3c3d5e375d731a88b40b8c45547b0.setIcon(icon_2ff133bce250e0bead869a09ca90075c);


            var marker_14904b3290fdbe7e1aafdc402546da20 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_237e4ba0690884da8635e879abdacc99 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_14904b3290fdbe7e1aafdc402546da20.setIcon(icon_237e4ba0690884da8635e879abdacc99);


            var marker_6fdbf82698ef366cecc3628b154f59ae = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f866b5f991d56ac703392526236056c2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6fdbf82698ef366cecc3628b154f59ae.setIcon(icon_f866b5f991d56ac703392526236056c2);


            var marker_270aa792f8c68486b9844da87109a36f = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8ce737eb4d8d78c8f70cab759ea77e3c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_270aa792f8c68486b9844da87109a36f.setIcon(icon_8ce737eb4d8d78c8f70cab759ea77e3c);


            var marker_9c3db26d8ea151009d7c43643fd3b604 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e025261e843af4fa8ae5c6ee1b6be5c0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9c3db26d8ea151009d7c43643fd3b604.setIcon(icon_e025261e843af4fa8ae5c6ee1b6be5c0);


            var marker_dbdab3632bfc114c413d6b2efd9c2252 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f16c3a9dc0e111e80eae01ae4969f1ce = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_dbdab3632bfc114c413d6b2efd9c2252.setIcon(icon_f16c3a9dc0e111e80eae01ae4969f1ce);


            var marker_c1f838986d59a2a5f4a3855f7fe39656 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_458ccb03f81ecf928867a4e6f47af47d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c1f838986d59a2a5f4a3855f7fe39656.setIcon(icon_458ccb03f81ecf928867a4e6f47af47d);


            var marker_56265f05ace24298e70a35d33ace89a3 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1c625d0dc4822c24567566984f3ef4f0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_56265f05ace24298e70a35d33ace89a3.setIcon(icon_1c625d0dc4822c24567566984f3ef4f0);


            var marker_c08f026651c0d3492167e206aac65544 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_17e8501ea7b51c18484c2f8a20d97a6e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c08f026651c0d3492167e206aac65544.setIcon(icon_17e8501ea7b51c18484c2f8a20d97a6e);


            var marker_ed1c640083154f993420ae190f2d44fe = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9e80b1839e371374d2952275bda7ea38 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ed1c640083154f993420ae190f2d44fe.setIcon(icon_9e80b1839e371374d2952275bda7ea38);


            var marker_42c2f319eecf29d8a70921be9ac14895 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2fedcfdd1562b4f0f0e3a4b0998ff6a0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_42c2f319eecf29d8a70921be9ac14895.setIcon(icon_2fedcfdd1562b4f0f0e3a4b0998ff6a0);


            var marker_747172ba2cbb31f2901d544d16fca8aa = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f4c0ae9d44cff23490a06b75f5f13417 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_747172ba2cbb31f2901d544d16fca8aa.setIcon(icon_f4c0ae9d44cff23490a06b75f5f13417);


            var marker_26aec00b27c4dda93d29f26720c496c1 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7e8f98d17141b493379620debaa9a3d1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_26aec00b27c4dda93d29f26720c496c1.setIcon(icon_7e8f98d17141b493379620debaa9a3d1);


            var marker_04c0aea758aacb37a0effbd742c04f54 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8c195cda60cf4c56a4972a84a4440dd0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_04c0aea758aacb37a0effbd742c04f54.setIcon(icon_8c195cda60cf4c56a4972a84a4440dd0);


            var marker_54e40503fd56f29bc81e7c26ae9553b6 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_20f10f191c09d35bd39a09691c2cd507 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_54e40503fd56f29bc81e7c26ae9553b6.setIcon(icon_20f10f191c09d35bd39a09691c2cd507);


            var marker_45a96aae430cc76fddcf101671b025fd = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0a7ac2a58156529897864dcaf8943cd7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_45a96aae430cc76fddcf101671b025fd.setIcon(icon_0a7ac2a58156529897864dcaf8943cd7);


            var marker_8b5a94437372963001b062c8d1a35335 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d77e6fb37d3ab4c55b59d4af5e81dc5e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8b5a94437372963001b062c8d1a35335.setIcon(icon_d77e6fb37d3ab4c55b59d4af5e81dc5e);


            var marker_7b15ed19d6607c748945652695488d0c = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_285c95e801a4455e7f7ba996fa35e8c5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7b15ed19d6607c748945652695488d0c.setIcon(icon_285c95e801a4455e7f7ba996fa35e8c5);


            var marker_d67f51b295bdaed70cb1460ea5501e77 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_698f2310bec56e4d31640f004a01920b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d67f51b295bdaed70cb1460ea5501e77.setIcon(icon_698f2310bec56e4d31640f004a01920b);


            var marker_67a1f8b1031c3d427c3205c4932e36a2 = L.marker(
                [34.07, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_96896931836ac81122c1e383a4e75ed9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_67a1f8b1031c3d427c3205c4932e36a2.setIcon(icon_96896931836ac81122c1e383a4e75ed9);


            var marker_f67cac46113fb5b55940e310569f7581 = L.marker(
                [34.06, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_749dc7d9336cfca6b128948311c7621a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f67cac46113fb5b55940e310569f7581.setIcon(icon_749dc7d9336cfca6b128948311c7621a);


            var marker_7dea9c6f9e9b6e5341a81f6c25c4be31 = L.marker(
                [34.06, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d368f754d6761909e9296b1a2c040bf3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7dea9c6f9e9b6e5341a81f6c25c4be31.setIcon(icon_d368f754d6761909e9296b1a2c040bf3);


            var marker_18f666fc22dd61ef99694b2e74d16292 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0357dd51142337fab4dc2c5cf18cc7df = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_18f666fc22dd61ef99694b2e74d16292.setIcon(icon_0357dd51142337fab4dc2c5cf18cc7df);


            var marker_39b6740eb54ebc084f502d6b579ce0d1 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e5e10a00979e26a1802c5c60186e2429 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_39b6740eb54ebc084f502d6b579ce0d1.setIcon(icon_e5e10a00979e26a1802c5c60186e2429);


            var marker_96211d842f19e19b8c641a7a5e232d2c = L.marker(
                [34.06, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6cef6763fd2296abb01d01bd1a7c4a01 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_96211d842f19e19b8c641a7a5e232d2c.setIcon(icon_6cef6763fd2296abb01d01bd1a7c4a01);


            var marker_66c92b0d2ec42188d793adf289369f3a = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b9a5edb829822c84123874c7ba7a3942 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_66c92b0d2ec42188d793adf289369f3a.setIcon(icon_b9a5edb829822c84123874c7ba7a3942);


            var marker_2d92de558d51f41c96a8ac20f8b37ba0 = L.marker(
                [34.05, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9bb68020d7b2e8e6ec7e93a3de117f30 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2d92de558d51f41c96a8ac20f8b37ba0.setIcon(icon_9bb68020d7b2e8e6ec7e93a3de117f30);


            var marker_99592c83ff97bcec558cde9a3260baa4 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_91ad9ebfcc73a1755052115bbcfad694 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_99592c83ff97bcec558cde9a3260baa4.setIcon(icon_91ad9ebfcc73a1755052115bbcfad694);


            var marker_fefdebf9ac14faf96a7619138e1fdc87 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a3e44206b285cb7a442fc083dc85f663 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_fefdebf9ac14faf96a7619138e1fdc87.setIcon(icon_a3e44206b285cb7a442fc083dc85f663);


            var marker_00170423d7b8f0de3395b39764216d1d = L.marker(
                [34.07, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c61adac7f00e6e80e6c931b365c4b0ab = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_00170423d7b8f0de3395b39764216d1d.setIcon(icon_c61adac7f00e6e80e6c931b365c4b0ab);


            var marker_85e4e4d9c8955bb5eb7180023a718f5b = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4d97e14a6516e7e9b11c29db20d40ec9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_85e4e4d9c8955bb5eb7180023a718f5b.setIcon(icon_4d97e14a6516e7e9b11c29db20d40ec9);


            var marker_3b44ad7528711b71cd82a9861c33c0a0 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d102e81126906bc21fec13428f595c4e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3b44ad7528711b71cd82a9861c33c0a0.setIcon(icon_d102e81126906bc21fec13428f595c4e);


            var marker_fbf41cc6dec4af1b0a81fd96ade29555 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_02c0f0e1d66c576cd4be94445349a4aa = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_fbf41cc6dec4af1b0a81fd96ade29555.setIcon(icon_02c0f0e1d66c576cd4be94445349a4aa);


            var marker_d6de3fb0c05f6a0ba5c6de024dedda9d = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a598e4d778db22d63ae8d40150c103f8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d6de3fb0c05f6a0ba5c6de024dedda9d.setIcon(icon_a598e4d778db22d63ae8d40150c103f8);


            var marker_2889aa0a16ab276406f4f259fa0d782f = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7bc9f3fdf6683dae29ab66667fdc0579 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2889aa0a16ab276406f4f259fa0d782f.setIcon(icon_7bc9f3fdf6683dae29ab66667fdc0579);


            var marker_33a928f13561fab1d0b89792974de6a3 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_821d418e9d6155438f9109450b5bfb23 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_33a928f13561fab1d0b89792974de6a3.setIcon(icon_821d418e9d6155438f9109450b5bfb23);


            var marker_5f4b7f13f378aed6c7a810ccaa25cb39 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_075120a5e47cd865022825e3481ad2fb = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5f4b7f13f378aed6c7a810ccaa25cb39.setIcon(icon_075120a5e47cd865022825e3481ad2fb);


            var marker_6022f8fd73093a2e21a6316d7c7c910d = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b86686e1b4fff15b26d2ebe01a614494 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6022f8fd73093a2e21a6316d7c7c910d.setIcon(icon_b86686e1b4fff15b26d2ebe01a614494);


            var marker_2d8fc5e39faeb532e68f7944da2353c5 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_76a137c250f19c29b5b3046d9cc5d178 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2d8fc5e39faeb532e68f7944da2353c5.setIcon(icon_76a137c250f19c29b5b3046d9cc5d178);


            var marker_23c4f055740e3356bae7729a43be71d5 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_46e43157853ee96f09a98bb69b4e0385 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_23c4f055740e3356bae7729a43be71d5.setIcon(icon_46e43157853ee96f09a98bb69b4e0385);


            var marker_cd9b41b894d46a86cb077b9223b4dcf2 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_20c4111c1b67cfcac184e02d580798b4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cd9b41b894d46a86cb077b9223b4dcf2.setIcon(icon_20c4111c1b67cfcac184e02d580798b4);


            var marker_9f3a92cce54ccef352d20a42a2437341 = L.marker(
                [34.27, -118.36],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_412ae6f82c73055d29b99d45b1b423c7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9f3a92cce54ccef352d20a42a2437341.setIcon(icon_412ae6f82c73055d29b99d45b1b423c7);


            var marker_4a1b8a50aaddb1bbb29539528a231575 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_32a2261959acc5da0c817a1d5f507f0b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4a1b8a50aaddb1bbb29539528a231575.setIcon(icon_32a2261959acc5da0c817a1d5f507f0b);


            var marker_ca50a42e0f6131f6500bcb5afe15fedb = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4de7d69c19aeb7b34b5e980f0add33c1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ca50a42e0f6131f6500bcb5afe15fedb.setIcon(icon_4de7d69c19aeb7b34b5e980f0add33c1);


            var marker_85b22298a670c5854e3d7f569f0c68bc = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_730cf886d0b6720d079275515fa1bf97 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_85b22298a670c5854e3d7f569f0c68bc.setIcon(icon_730cf886d0b6720d079275515fa1bf97);


            var marker_938f6c6bed8e93c08446ee1fc1dda806 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9fdd87137761e65353388d6a3158a1dd = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_938f6c6bed8e93c08446ee1fc1dda806.setIcon(icon_9fdd87137761e65353388d6a3158a1dd);


            var marker_3823029d4f62c967b6e6731ac7e838aa = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_db508f6dccc011ed414f0d579ec6980e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3823029d4f62c967b6e6731ac7e838aa.setIcon(icon_db508f6dccc011ed414f0d579ec6980e);


            var marker_b34cc7cc870307276294511c68f65d9d = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2a2a9ce27c56ba812ba32ae38112b23d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b34cc7cc870307276294511c68f65d9d.setIcon(icon_2a2a9ce27c56ba812ba32ae38112b23d);


            var marker_8d1cc48aba4935a72b68d0fbf908b8d0 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_248ca0c563c7262c3a234a8700420d56 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8d1cc48aba4935a72b68d0fbf908b8d0.setIcon(icon_248ca0c563c7262c3a234a8700420d56);


            var marker_ee66079fe614786e0bdbb5cea7db218f = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d620fc08c509b58b6a8adcdc5ab41551 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ee66079fe614786e0bdbb5cea7db218f.setIcon(icon_d620fc08c509b58b6a8adcdc5ab41551);


            var marker_e62eae7d8b257ff50478b518cb3e52fa = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5a726bbc8ca49e33e7ae59c2b677f777 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e62eae7d8b257ff50478b518cb3e52fa.setIcon(icon_5a726bbc8ca49e33e7ae59c2b677f777);


            var marker_f9aa1e677d03ccf42ed9822e43cb2c4d = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b8a3027d979f0f4e614395c724da64ce = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f9aa1e677d03ccf42ed9822e43cb2c4d.setIcon(icon_b8a3027d979f0f4e614395c724da64ce);


            var marker_ad769f27e71df6c9e065d11fe5f6dad9 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d7665559d5cc447ae63d295ab26e1561 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ad769f27e71df6c9e065d11fe5f6dad9.setIcon(icon_d7665559d5cc447ae63d295ab26e1561);


            var marker_e63382dfd99bda0a74c9e48b0a42f995 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d41faba78baf0beaa6695d039a394123 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e63382dfd99bda0a74c9e48b0a42f995.setIcon(icon_d41faba78baf0beaa6695d039a394123);


            var marker_5a4eaa5fe6c9e348f51fbe81a92dbb07 = L.marker(
                [34.07, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c459676a984d519d6b52f9ef199d990e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5a4eaa5fe6c9e348f51fbe81a92dbb07.setIcon(icon_c459676a984d519d6b52f9ef199d990e);


            var marker_824bcbe04fe01e75a7fa1c720ceca480 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f1df806d3314f207a1b37066d8945681 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_824bcbe04fe01e75a7fa1c720ceca480.setIcon(icon_f1df806d3314f207a1b37066d8945681);


            var marker_46636441cffff7a0a1632ab707e88d79 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1ef4b934623bf8f4b3e8c75271730216 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_46636441cffff7a0a1632ab707e88d79.setIcon(icon_1ef4b934623bf8f4b3e8c75271730216);


            var marker_c980cfbeb02a83f4f9e5f6e56a72bb5c = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_da3903102404b80e1cacb56d8a4cb0af = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c980cfbeb02a83f4f9e5f6e56a72bb5c.setIcon(icon_da3903102404b80e1cacb56d8a4cb0af);


            var marker_9fb47c3855582a5e507fcd965bbec490 = L.marker(
                [34.03, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8d99c745c55f29e49f1745a102d502f2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9fb47c3855582a5e507fcd965bbec490.setIcon(icon_8d99c745c55f29e49f1745a102d502f2);


            var marker_0add2e07981db66eda0e82fe83b01050 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0a2b8aa07c974af3cfd8c4060e0ce082 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0add2e07981db66eda0e82fe83b01050.setIcon(icon_0a2b8aa07c974af3cfd8c4060e0ce082);


            var marker_6638d22e9ede872136eb9dbf130fb1e0 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_02a645e8b1133b906ca0074a61eb3aa0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6638d22e9ede872136eb9dbf130fb1e0.setIcon(icon_02a645e8b1133b906ca0074a61eb3aa0);


            var marker_44d8c99734eea47f73da5bfce6e01186 = L.marker(
                [34.1, -118.33],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_91007a7b5f5038049b76f8d63da1bcaa = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_44d8c99734eea47f73da5bfce6e01186.setIcon(icon_91007a7b5f5038049b76f8d63da1bcaa);


            var marker_a10cad6327f2f053b736f19d37d78f44 = L.marker(
                [34.1, -118.34],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f10ca0acbe2d6282e0c0afd4eecdf613 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a10cad6327f2f053b736f19d37d78f44.setIcon(icon_f10ca0acbe2d6282e0c0afd4eecdf613);


            var marker_54d8b49108c5c1078b70036ddf885cad = L.marker(
                [34.02, -118.3],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a26a182b39921c2cf70ac295fed31fe9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_54d8b49108c5c1078b70036ddf885cad.setIcon(icon_a26a182b39921c2cf70ac295fed31fe9);


            var marker_4f28dfba4e2967e63b5987dac2817b6e = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f75abc14834f8af516d3df8222964fb3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4f28dfba4e2967e63b5987dac2817b6e.setIcon(icon_f75abc14834f8af516d3df8222964fb3);


            var marker_7cf02bdf4b57fc2fb8b14dc4263f933e = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f11d33e2d257e20b501028ea7da075ac = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7cf02bdf4b57fc2fb8b14dc4263f933e.setIcon(icon_f11d33e2d257e20b501028ea7da075ac);


            var marker_856ff860fdbf1d307f8b9ca99ed5d4b1 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0bed5112fb76ed88b850fc7495799d12 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_856ff860fdbf1d307f8b9ca99ed5d4b1.setIcon(icon_0bed5112fb76ed88b850fc7495799d12);


            var marker_b5f5ba42f9de0745bd570a85da657a1c = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_771cdd96879b89f3590b3870d92c6d1e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b5f5ba42f9de0745bd570a85da657a1c.setIcon(icon_771cdd96879b89f3590b3870d92c6d1e);


            var marker_7088b44d648dfed0e6adad2817171a54 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_981382d3246c3d44c83efbe9d66261a7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7088b44d648dfed0e6adad2817171a54.setIcon(icon_981382d3246c3d44c83efbe9d66261a7);


            var marker_a669d7a27c75e10088351bb0bbef59ef = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3097798b2865608a5e8fe331574fa22c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a669d7a27c75e10088351bb0bbef59ef.setIcon(icon_3097798b2865608a5e8fe331574fa22c);


            var marker_d2d662601d9a12a25af5f8c520019afd = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_02d443e03f2243f8a08f1735287f1766 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d2d662601d9a12a25af5f8c520019afd.setIcon(icon_02d443e03f2243f8a08f1735287f1766);


            var marker_e5cfece599c198b5ec0dd702921c718c = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4c3bb498470abc936e0de01f029c6397 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e5cfece599c198b5ec0dd702921c718c.setIcon(icon_4c3bb498470abc936e0de01f029c6397);


            var marker_39a4e3f24d923d73aad228c109facce3 = L.marker(
                [34.23, -118.37],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4cbf5b29b5dcd167680ec98d7375add8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_39a4e3f24d923d73aad228c109facce3.setIcon(icon_4cbf5b29b5dcd167680ec98d7375add8);


            var marker_c6cc423bbc6583284ab907964cb50951 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a7f4e83eb0f172f55fd184a25ebb50d9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c6cc423bbc6583284ab907964cb50951.setIcon(icon_a7f4e83eb0f172f55fd184a25ebb50d9);


            var marker_f198704d45b05ec8bc1265349ef06983 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b8d9d75fa1bb524a8f06be4cd0306a67 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f198704d45b05ec8bc1265349ef06983.setIcon(icon_b8d9d75fa1bb524a8f06be4cd0306a67);


            var marker_229d333531e6af9ada406e06e67b0291 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1a9832eea15d4a699f1f4706f301462f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_229d333531e6af9ada406e06e67b0291.setIcon(icon_1a9832eea15d4a699f1f4706f301462f);


            var marker_30d3574551de3e8e959e538af9cf7596 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e9470d66b2ea9ba2573aaa46bbdca25e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_30d3574551de3e8e959e538af9cf7596.setIcon(icon_e9470d66b2ea9ba2573aaa46bbdca25e);


            var marker_046b2eafd57df1c5f6f6a9cbeccb990e = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_27f49f05e3a13a65014f4af5d988e378 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_046b2eafd57df1c5f6f6a9cbeccb990e.setIcon(icon_27f49f05e3a13a65014f4af5d988e378);


            var marker_633e0d72e70f910ed307a0f804cc1540 = L.marker(
                [34.05, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_05ecddd731d138fc7635339b92745067 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_633e0d72e70f910ed307a0f804cc1540.setIcon(icon_05ecddd731d138fc7635339b92745067);


            var marker_857b31fa4109606d04427c2af613f1c5 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4c03bc8c82a603ddad37e3e507e6af82 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_857b31fa4109606d04427c2af613f1c5.setIcon(icon_4c03bc8c82a603ddad37e3e507e6af82);


            var marker_9506e6c0d2cefc83bd2ed9bf83e33f02 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_39d1582c8579de2fff19f0f9f991ca4f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9506e6c0d2cefc83bd2ed9bf83e33f02.setIcon(icon_39d1582c8579de2fff19f0f9f991ca4f);


            var marker_cec3e5cae3d3b07c3d554eb558d2fd3b = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_81c572dda36e6740f608ef6c325f64d3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cec3e5cae3d3b07c3d554eb558d2fd3b.setIcon(icon_81c572dda36e6740f608ef6c325f64d3);


            var marker_4b55315794eac8c857127244a3cbf356 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_25466cff37d2cdfbe4b01efa4b81fd31 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4b55315794eac8c857127244a3cbf356.setIcon(icon_25466cff37d2cdfbe4b01efa4b81fd31);


            var marker_78c7d59c8549fc1b5ed02fd981ee24a9 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d92a17575b1f7782da42172c805eade8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_78c7d59c8549fc1b5ed02fd981ee24a9.setIcon(icon_d92a17575b1f7782da42172c805eade8);


            var marker_c856c74938547babfb07345e199f9512 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4c8b17756f893758eac267aab96c6ab0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c856c74938547babfb07345e199f9512.setIcon(icon_4c8b17756f893758eac267aab96c6ab0);


            var marker_266e7785129c1229d8032ac4e55ea6fc = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e1d9d4f2949a734a56fc3588234e1867 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_266e7785129c1229d8032ac4e55ea6fc.setIcon(icon_e1d9d4f2949a734a56fc3588234e1867);


            var marker_19249ae00f5b32c0f5f291c51a750903 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_692f1a9bad9b9a4ddff8957c5ef67ed1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_19249ae00f5b32c0f5f291c51a750903.setIcon(icon_692f1a9bad9b9a4ddff8957c5ef67ed1);


            var marker_35bb0660ff462669bb78c30477772db2 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_039f8cded530d9ffb8fa09d1d32e7f0b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_35bb0660ff462669bb78c30477772db2.setIcon(icon_039f8cded530d9ffb8fa09d1d32e7f0b);


            var marker_4c893181efb0c18deb53c1f0abdd3f72 = L.marker(
                [34.04, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d116719cc65847af5e3689309fc35c71 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4c893181efb0c18deb53c1f0abdd3f72.setIcon(icon_d116719cc65847af5e3689309fc35c71);


            var marker_b96a3f1f7614d6ab4bbb0b82d388e859 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1f5e7d697c26a095e219d3d23158e26b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b96a3f1f7614d6ab4bbb0b82d388e859.setIcon(icon_1f5e7d697c26a095e219d3d23158e26b);


            var marker_fec29155d13c0806ee6aa5972b0131a8 = L.marker(
                [34.06, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0ac241332681670aa6c1fbe24e7bfe8a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_fec29155d13c0806ee6aa5972b0131a8.setIcon(icon_0ac241332681670aa6c1fbe24e7bfe8a);


            var marker_24cb685e15df5b73d853466ea06b82aa = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_547de5b72eb48a4e55e4c245b6dc6a0e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_24cb685e15df5b73d853466ea06b82aa.setIcon(icon_547de5b72eb48a4e55e4c245b6dc6a0e);


            var marker_a6215a7c8110433db8a934e7f45a44cd = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_18c0e8553abef5ee378bd84ae61a6977 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a6215a7c8110433db8a934e7f45a44cd.setIcon(icon_18c0e8553abef5ee378bd84ae61a6977);


            var marker_545af5f9ff5a4e0597ee7eb921757a7c = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a1f6f4ca71e79d26517eb20f18e972ca = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_545af5f9ff5a4e0597ee7eb921757a7c.setIcon(icon_a1f6f4ca71e79d26517eb20f18e972ca);


            var marker_0f042e20a9946e3194e83c451d9c3016 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ed130bc57777a092b804c283b6bc91e0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0f042e20a9946e3194e83c451d9c3016.setIcon(icon_ed130bc57777a092b804c283b6bc91e0);


            var marker_7cdfc77d324d5cb9cb388dc5b4856c22 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5e49a20b43ac8b626c7c707dc474efef = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7cdfc77d324d5cb9cb388dc5b4856c22.setIcon(icon_5e49a20b43ac8b626c7c707dc474efef);


            var marker_772878bb9eedcfeeaf0f6bb248452d21 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ebeab278c4e782feccfc44b848ec47a8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_772878bb9eedcfeeaf0f6bb248452d21.setIcon(icon_ebeab278c4e782feccfc44b848ec47a8);


            var marker_02837d6e0a69d75c6e1738d20a42f2cf = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6d3d9cf579a58b564732421520943988 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_02837d6e0a69d75c6e1738d20a42f2cf.setIcon(icon_6d3d9cf579a58b564732421520943988);


            var marker_27069b1e9e56b69b304b8cb7c07b1738 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_66be1b7a0d200c9d1b844b09bc628305 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_27069b1e9e56b69b304b8cb7c07b1738.setIcon(icon_66be1b7a0d200c9d1b844b09bc628305);


            var marker_9992e4da86e28f917a09bae62322af52 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0c9ae6b213ac90faa80dace57506e9f7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9992e4da86e28f917a09bae62322af52.setIcon(icon_0c9ae6b213ac90faa80dace57506e9f7);


            var marker_32b4d18df0791acc85a5784d96296679 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9015e6b73e68c1d3648701818e79dfa2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_32b4d18df0791acc85a5784d96296679.setIcon(icon_9015e6b73e68c1d3648701818e79dfa2);


            var marker_f17d3604057d518ac971c32d5089c4e8 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_be3ea4d849016fef6bd164faf2d7d9dc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f17d3604057d518ac971c32d5089c4e8.setIcon(icon_be3ea4d849016fef6bd164faf2d7d9dc);


            var marker_997db0c7ab6dec1d2c7e670b18d5a884 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7c881a2e8dab3f33b063448f740e5be9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_997db0c7ab6dec1d2c7e670b18d5a884.setIcon(icon_7c881a2e8dab3f33b063448f740e5be9);


            var marker_d20bba7ffb6ae5452c78035689feb000 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_06a65ccc17b2c10736eda30cc2d56e2d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d20bba7ffb6ae5452c78035689feb000.setIcon(icon_06a65ccc17b2c10736eda30cc2d56e2d);


            var marker_b251a961df056832cefa923861aa31f3 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c158b8bc6c4ad55927abf3aab3b3ed77 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b251a961df056832cefa923861aa31f3.setIcon(icon_c158b8bc6c4ad55927abf3aab3b3ed77);


            var marker_4d3fce145924e17cccfa5323f6299cd9 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_13598a7649aa44c8630126f75f774cd9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4d3fce145924e17cccfa5323f6299cd9.setIcon(icon_13598a7649aa44c8630126f75f774cd9);


            var marker_74360d9f94814911fa0e9b5b42c60395 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_afc9ed11fbc4fcb41c07d1a46855c3d9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_74360d9f94814911fa0e9b5b42c60395.setIcon(icon_afc9ed11fbc4fcb41c07d1a46855c3d9);


            var marker_c7d5ad43bc2ad9361540726befd7cece = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_92c1504028a581c3809820368f1497e7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c7d5ad43bc2ad9361540726befd7cece.setIcon(icon_92c1504028a581c3809820368f1497e7);


            var marker_b7a089c886b277babde10337b64be8a1 = L.marker(
                [34.07, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_13b917b58a8c4c7d56988e74bfaa5715 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b7a089c886b277babde10337b64be8a1.setIcon(icon_13b917b58a8c4c7d56988e74bfaa5715);


            var marker_42a902444c9379bef2fa7442c77ba23a = L.marker(
                [34.03, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3cddc1c7fd3618e6973a2505218ceb20 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_42a902444c9379bef2fa7442c77ba23a.setIcon(icon_3cddc1c7fd3618e6973a2505218ceb20);


            var marker_01d3b7a46cf71ca9e9f50721d2351569 = L.marker(
                [34.06, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_081e9066e443a8805cefd426918f01fc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_01d3b7a46cf71ca9e9f50721d2351569.setIcon(icon_081e9066e443a8805cefd426918f01fc);


            var marker_de29a8ed81adf60ba0812f0a44a810ac = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_31b9656a7a7526411b0fc263f2d1b65a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_de29a8ed81adf60ba0812f0a44a810ac.setIcon(icon_31b9656a7a7526411b0fc263f2d1b65a);


            var marker_cca5e4ce707b0fd7c1b7d09dd1fac4a7 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c00e461c710ee1b026f1ecf5bd8fbbf9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cca5e4ce707b0fd7c1b7d09dd1fac4a7.setIcon(icon_c00e461c710ee1b026f1ecf5bd8fbbf9);


            var marker_22c14acab724be640060f5aaa47567c1 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b09b489c75c40180e1ad0032f4f89f3c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_22c14acab724be640060f5aaa47567c1.setIcon(icon_b09b489c75c40180e1ad0032f4f89f3c);


            var marker_f437b0aa08faa02097590c40a733c2db = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3fc4b33f6c380fc4da816ebe2a6a8546 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f437b0aa08faa02097590c40a733c2db.setIcon(icon_3fc4b33f6c380fc4da816ebe2a6a8546);


            var marker_201d3611d2116378366c65a7f9a5009a = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8fe9e5b2b3fb3a4ef826e1639558730a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_201d3611d2116378366c65a7f9a5009a.setIcon(icon_8fe9e5b2b3fb3a4ef826e1639558730a);


            var marker_decf99f673e75b7c46f353fad027495a = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f09cbd26ae6aa9a1bfee86bf5058eab9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_decf99f673e75b7c46f353fad027495a.setIcon(icon_f09cbd26ae6aa9a1bfee86bf5058eab9);


            var marker_e426812282117768df55c619c905a2d5 = L.marker(
                [34.06, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f1d3505e9475683d64e4ab56dd59cf19 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e426812282117768df55c619c905a2d5.setIcon(icon_f1d3505e9475683d64e4ab56dd59cf19);


            var marker_8c46978fd00b08bbdcc20ccfcafe2d7c = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_64f71fc670ca9a50e44ea73e92db55f9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8c46978fd00b08bbdcc20ccfcafe2d7c.setIcon(icon_64f71fc670ca9a50e44ea73e92db55f9);


            var marker_d3e40681edbba4e61ccaf72648be8c99 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3d08aafe71ab688293c13ad765b2823e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d3e40681edbba4e61ccaf72648be8c99.setIcon(icon_3d08aafe71ab688293c13ad765b2823e);


            var marker_1fecd22b9e7dbe62f7e3ab88f085f630 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5a1e74123d95383ecd94a81722f10f4e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_1fecd22b9e7dbe62f7e3ab88f085f630.setIcon(icon_5a1e74123d95383ecd94a81722f10f4e);


            var marker_26aaf831bf5d7c1bfd18a3ce6a3465d4 = L.marker(
                [34.07, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_040e75bd2a73d516a9a65366d132acd4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_26aaf831bf5d7c1bfd18a3ce6a3465d4.setIcon(icon_040e75bd2a73d516a9a65366d132acd4);


            var marker_2f9a1cd8a302f5e9e92045d4fee7043a = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5baaecb7d9c66fcb74f8725343cd3ebd = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2f9a1cd8a302f5e9e92045d4fee7043a.setIcon(icon_5baaecb7d9c66fcb74f8725343cd3ebd);


            var marker_6be998482e08a2c1356747c288c072ce = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_715d4ca2e69de4304bb51e494d465bb7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6be998482e08a2c1356747c288c072ce.setIcon(icon_715d4ca2e69de4304bb51e494d465bb7);


            var marker_0b8fbe40c9b9893b5f6d3557bcfe445f = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e0ef1b409aa09aabd6e367e6814b0d78 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0b8fbe40c9b9893b5f6d3557bcfe445f.setIcon(icon_e0ef1b409aa09aabd6e367e6814b0d78);


            var marker_4df65de8f406563ebc4eb9ab8edd1a3c = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7b7172f6dc1a0cd9c5e72776a3911984 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4df65de8f406563ebc4eb9ab8edd1a3c.setIcon(icon_7b7172f6dc1a0cd9c5e72776a3911984);


            var marker_2551dbd0e29ee39f9d104c2612a57308 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3d35c6f213abd0563f9a748cfa0578e9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2551dbd0e29ee39f9d104c2612a57308.setIcon(icon_3d35c6f213abd0563f9a748cfa0578e9);


            var marker_7cb808340240c40a975bd1417e125bd5 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f2ec7b0093c1c539093fcc898ff7371e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7cb808340240c40a975bd1417e125bd5.setIcon(icon_f2ec7b0093c1c539093fcc898ff7371e);


            var marker_c4b79681a3ca3ef7a362a855810874cc = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0314ddcdb4aba8accdf1fc32f016ec03 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c4b79681a3ca3ef7a362a855810874cc.setIcon(icon_0314ddcdb4aba8accdf1fc32f016ec03);


            var marker_19c8ad9aaedd9eb69b8ad11f77f1c802 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8e89c96776826b907ae8ae314043dd8a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_19c8ad9aaedd9eb69b8ad11f77f1c802.setIcon(icon_8e89c96776826b907ae8ae314043dd8a);


            var marker_0c5dab900c91b75843c8600d442ed649 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_25010c95e3a3dbed030fdd9574672357 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0c5dab900c91b75843c8600d442ed649.setIcon(icon_25010c95e3a3dbed030fdd9574672357);


            var marker_b79c9f5fdedf95d718e86dd1cb708c04 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_418cbfa27f5c4354d1908ae8e3cf2791 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b79c9f5fdedf95d718e86dd1cb708c04.setIcon(icon_418cbfa27f5c4354d1908ae8e3cf2791);


            var marker_7ff39b51d3336844c8451a6c56386d0e = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_da309134a30a8e9f8af43ed990deea69 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7ff39b51d3336844c8451a6c56386d0e.setIcon(icon_da309134a30a8e9f8af43ed990deea69);


            var marker_454b39e0a5a540f156dd0667e6940128 = L.marker(
                [34.2, -118.46],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3aac5edbc01b57bb196f1d06ee58eb4d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_454b39e0a5a540f156dd0667e6940128.setIcon(icon_3aac5edbc01b57bb196f1d06ee58eb4d);


            var marker_a3669f49044b9864442244d9a22c7bdb = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5950640a99736b80947e565986636176 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a3669f49044b9864442244d9a22c7bdb.setIcon(icon_5950640a99736b80947e565986636176);


            var marker_001644bd7f298ba44427d8397382fdc6 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_fd3a1f8914e4584bb960017297d34f77 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_001644bd7f298ba44427d8397382fdc6.setIcon(icon_fd3a1f8914e4584bb960017297d34f77);


            var marker_891b06c03b10c514d5d39892a7c0aa5f = L.marker(
                [34.21, -118.56],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_12441804844a584e4fd38eb99fdea0c8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_891b06c03b10c514d5d39892a7c0aa5f.setIcon(icon_12441804844a584e4fd38eb99fdea0c8);


            var marker_f627e8d13473ef07ca456a23ca2f35cf = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cddd705c18afb192c7bfcb2c89a5cb7f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f627e8d13473ef07ca456a23ca2f35cf.setIcon(icon_cddd705c18afb192c7bfcb2c89a5cb7f);


            var marker_0d19d57fd1c06e53d207fbc476ac8ea1 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_26d1221704ad959be8b065f1503b9c22 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0d19d57fd1c06e53d207fbc476ac8ea1.setIcon(icon_26d1221704ad959be8b065f1503b9c22);


            var marker_25e897b0916e52c4993a826e4b7089fc = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ff8a75a0bb85477fa0aff2b7bab9b40d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_25e897b0916e52c4993a826e4b7089fc.setIcon(icon_ff8a75a0bb85477fa0aff2b7bab9b40d);


            var marker_9a4809dd999bff4966cb6963faead2e9 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7b2df192249d2b58281d01b2055c25d0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9a4809dd999bff4966cb6963faead2e9.setIcon(icon_7b2df192249d2b58281d01b2055c25d0);


            var marker_ad014f99c180ad262c54dd56466b7a18 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_da1d5ee6395b69f25f70f530c5e99af4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ad014f99c180ad262c54dd56466b7a18.setIcon(icon_da1d5ee6395b69f25f70f530c5e99af4);


            var marker_e4f459e7c7d90aa03ca3a11d04606162 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_bbc9f924f1722384256190d6ff6bc9a6 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e4f459e7c7d90aa03ca3a11d04606162.setIcon(icon_bbc9f924f1722384256190d6ff6bc9a6);


            var marker_0411bdd22295d906adb7581739684f47 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_44aeac72dbce8f7cbbf864120cb3caaf = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0411bdd22295d906adb7581739684f47.setIcon(icon_44aeac72dbce8f7cbbf864120cb3caaf);


            var marker_784335ad7150f0068946a07a0a717ae1 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_292a49d2fa724a604c07d78357bb1e54 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_784335ad7150f0068946a07a0a717ae1.setIcon(icon_292a49d2fa724a604c07d78357bb1e54);


            var marker_b2c5a9e5d5d6fc0dccd465f2ee67ade3 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0e39ee46179f2a226974ae5f4a4ae09a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b2c5a9e5d5d6fc0dccd465f2ee67ade3.setIcon(icon_0e39ee46179f2a226974ae5f4a4ae09a);


            var marker_9cc5cbbdffe0db1a67fcab5efef49ba1 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_453fa97ab763e1a06d1400aaa48477ce = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9cc5cbbdffe0db1a67fcab5efef49ba1.setIcon(icon_453fa97ab763e1a06d1400aaa48477ce);


            var marker_95939d55d945314505d4cf38778adadf = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_41c355f7e4d22aabfafd420815bbb10d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_95939d55d945314505d4cf38778adadf.setIcon(icon_41c355f7e4d22aabfafd420815bbb10d);


            var marker_c4b5a837edb92b75c7daab2d517ca56b = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e4d13becbee9c849dffeb65969b82a05 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c4b5a837edb92b75c7daab2d517ca56b.setIcon(icon_e4d13becbee9c849dffeb65969b82a05);


            var marker_d2eed4a5e70e8c494e9e61045e896f3a = L.marker(
                [34.05, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e2d8b910b185b9bfaf6cc7c8526de74b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d2eed4a5e70e8c494e9e61045e896f3a.setIcon(icon_e2d8b910b185b9bfaf6cc7c8526de74b);


            var marker_ef4c15b3d685b140ea334193b97a10df = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_626c83a49eca106556a75bb1464bd88a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ef4c15b3d685b140ea334193b97a10df.setIcon(icon_626c83a49eca106556a75bb1464bd88a);


            var marker_77ae9c76e410311f16ff230455d4b6e9 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8de94392af06f555506c54c9739b9b69 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_77ae9c76e410311f16ff230455d4b6e9.setIcon(icon_8de94392af06f555506c54c9739b9b69);


            var marker_3830470b3cfb7ffb9327f5f02fdcf9be = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_61f037b63d80ccf383bf94911832f7f3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3830470b3cfb7ffb9327f5f02fdcf9be.setIcon(icon_61f037b63d80ccf383bf94911832f7f3);


            var marker_5c97c4b3d213fc4865501daf68b64448 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2f7da70f97e1bf3d0edb1eb7f3af621b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5c97c4b3d213fc4865501daf68b64448.setIcon(icon_2f7da70f97e1bf3d0edb1eb7f3af621b);


            var marker_c3eaf1a32f2dfe552bed17b98493ae84 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_372ee84578ab3e2c77bcc3d018ca62c9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c3eaf1a32f2dfe552bed17b98493ae84.setIcon(icon_372ee84578ab3e2c77bcc3d018ca62c9);


            var marker_33ef70652abe54c58cbac1eb1887ca03 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_660e000a5c7e5b174a86297036e4d624 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_33ef70652abe54c58cbac1eb1887ca03.setIcon(icon_660e000a5c7e5b174a86297036e4d624);


            var marker_e39d34ff4b42c4946a9165ce018d2c3c = L.marker(
                [34.05, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4b6202222df08ee763ebb34d289722f6 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e39d34ff4b42c4946a9165ce018d2c3c.setIcon(icon_4b6202222df08ee763ebb34d289722f6);


            var marker_77d4b70125cb554bdbb48506095b1ef4 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b292be17d793a3e26ded9092b68fb0be = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_77d4b70125cb554bdbb48506095b1ef4.setIcon(icon_b292be17d793a3e26ded9092b68fb0be);


            var marker_bc7b00efa2918503d2810c72c98a5aea = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b88a7d6168a995af4238d3355bc0436a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_bc7b00efa2918503d2810c72c98a5aea.setIcon(icon_b88a7d6168a995af4238d3355bc0436a);


            var marker_56a6379383f34cae3d0364438a4305b1 = L.marker(
                [33.78, -118.28],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1f4baa460239c7c331e48e08c00b0722 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_56a6379383f34cae3d0364438a4305b1.setIcon(icon_1f4baa460239c7c331e48e08c00b0722);


            var marker_80efc063459dd38fa398dd8e696270fd = L.marker(
                [34.05, -118.28],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_89436b9815f97c3fdb277f32865dac48 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_80efc063459dd38fa398dd8e696270fd.setIcon(icon_89436b9815f97c3fdb277f32865dac48);


            var marker_33527c2586aef70978a68dd3199d0b67 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7b10511d9a6693cff92791dafb9179d8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_33527c2586aef70978a68dd3199d0b67.setIcon(icon_7b10511d9a6693cff92791dafb9179d8);


            var marker_889eabf2b85210c04d79c0acafaf811d = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cf976a1a45cf1481a56c300a3aeaac1b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_889eabf2b85210c04d79c0acafaf811d.setIcon(icon_cf976a1a45cf1481a56c300a3aeaac1b);


            var marker_d6c8d4716183b916f6dfc08a68bfd969 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0a65d7ed3a38d329bcee2871b9473b15 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d6c8d4716183b916f6dfc08a68bfd969.setIcon(icon_0a65d7ed3a38d329bcee2871b9473b15);


            var marker_e13f97852aa463fbc39c706dc8d1056a = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_619bca9300467e92cd14d8daeb608961 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e13f97852aa463fbc39c706dc8d1056a.setIcon(icon_619bca9300467e92cd14d8daeb608961);


            var marker_ac2158aee666daf4745a28adbec5c0aa = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_422ef957246284c3140340c5c247e49f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ac2158aee666daf4745a28adbec5c0aa.setIcon(icon_422ef957246284c3140340c5c247e49f);


            var marker_1c229e2f32f0ff61647b1e6aab4c81a6 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b4b86b1339d0015c4219016d83f04641 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_1c229e2f32f0ff61647b1e6aab4c81a6.setIcon(icon_b4b86b1339d0015c4219016d83f04641);


            var marker_11f5342587b7e9b58c2cc4abcc7c2e95 = L.marker(
                [34.1, -118.33],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_36125cc7aad319ad13f0979f6ba83c6a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_11f5342587b7e9b58c2cc4abcc7c2e95.setIcon(icon_36125cc7aad319ad13f0979f6ba83c6a);


            var marker_be07f3ad009ddafd6444e5bf7276cc54 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e298de6fd535ab5a27c4c4a2049804a2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_be07f3ad009ddafd6444e5bf7276cc54.setIcon(icon_e298de6fd535ab5a27c4c4a2049804a2);


            var marker_123985381928f4d5000c51b3c130f46b = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_dfb4f6d0a50e1a6b96e9b01e8ae7c01b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_123985381928f4d5000c51b3c130f46b.setIcon(icon_dfb4f6d0a50e1a6b96e9b01e8ae7c01b);


            var marker_324a22966318fb3f13e257a68f3c667d = L.marker(
                [33.72, -118.29],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ee47e1c2b8f06f90ce34b61a3338d63b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_324a22966318fb3f13e257a68f3c667d.setIcon(icon_ee47e1c2b8f06f90ce34b61a3338d63b);


            var marker_bde852a10daa3b55f480199fc379b9d3 = L.marker(
                [34.05, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9d5253c21ce0bb127fb5f0a21985797d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_bde852a10daa3b55f480199fc379b9d3.setIcon(icon_9d5253c21ce0bb127fb5f0a21985797d);


            var marker_72d16da3adb8806093e7dd1684a13109 = L.marker(
                [34.06, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1ee222f1fcaa42f5008041f2cc66a1e6 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_72d16da3adb8806093e7dd1684a13109.setIcon(icon_1ee222f1fcaa42f5008041f2cc66a1e6);


            var marker_36751abe9080fd51f023e4b85968d1b4 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f32dfe6d0a3c902afaaf5de38fcde31d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_36751abe9080fd51f023e4b85968d1b4.setIcon(icon_f32dfe6d0a3c902afaaf5de38fcde31d);


            var marker_6fe40475f08b322875c055c8cf2242e7 = L.marker(
                [34.08, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9497331fe6448be55b710ef884172583 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6fe40475f08b322875c055c8cf2242e7.setIcon(icon_9497331fe6448be55b710ef884172583);


            var marker_714a2187ec03a57cb3db5184ca94a7fe = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3ec50c9ec575f2742f7f60c88818e703 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_714a2187ec03a57cb3db5184ca94a7fe.setIcon(icon_3ec50c9ec575f2742f7f60c88818e703);


            var marker_031fbbd179a29186b77f92e7a7fd8299 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_de1e8e0a369d63a724943d0303ed87d8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_031fbbd179a29186b77f92e7a7fd8299.setIcon(icon_de1e8e0a369d63a724943d0303ed87d8);


            var marker_ca8cca862415c58833768e599aac2d05 = L.marker(
                [33.79, -118.29],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f566ef64f4dec46be24f3fe881f5c182 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ca8cca862415c58833768e599aac2d05.setIcon(icon_f566ef64f4dec46be24f3fe881f5c182);


            var marker_5f18ab33098824ee7c4821aa475179ff = L.marker(
                [33.98, -118.32],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f0d8804f916a5505c36744de3737fd08 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5f18ab33098824ee7c4821aa475179ff.setIcon(icon_f0d8804f916a5505c36744de3737fd08);


            var marker_dbc0ed06668cd102e43b308be6e5a129 = L.marker(
                [34.21, -118.41],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_02fbd765061b275a73f72ca93c0a9b0a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_dbc0ed06668cd102e43b308be6e5a129.setIcon(icon_02fbd765061b275a73f72ca93c0a9b0a);


            var marker_633e42a2aec4d3c8b06b72173630ea85 = L.marker(
                [34.1, -118.32],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cc9b79b7e1d14d69ea987d95405c4309 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_633e42a2aec4d3c8b06b72173630ea85.setIcon(icon_cc9b79b7e1d14d69ea987d95405c4309);


            var marker_5b330c2135f1bf107e0670928994227e = L.marker(
                [34.08, -118.3],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_fc06c76fb328fd99e176b9645dadd0e0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5b330c2135f1bf107e0670928994227e.setIcon(icon_fc06c76fb328fd99e176b9645dadd0e0);


            var marker_10e300745a66f63848062020a3621d9f = L.marker(
                [34.05, -118.3],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d95a50047c79bda45de9e41d93339cd7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_10e300745a66f63848062020a3621d9f.setIcon(icon_d95a50047c79bda45de9e41d93339cd7);


            var marker_cff18f7ba2e330eb786bd2e7f82a208e = L.marker(
                [34.28, -118.47],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2d87aa2a0ddc616da030359484c513b7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cff18f7ba2e330eb786bd2e7f82a208e.setIcon(icon_2d87aa2a0ddc616da030359484c513b7);


            var marker_134e052ca2ea4303865db85199bc5363 = L.marker(
                [33.71, -118.29],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_61015aebfcd789cdbd2c73d6607aca1b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_134e052ca2ea4303865db85199bc5363.setIcon(icon_61015aebfcd789cdbd2c73d6607aca1b);


            var marker_063b6c3a2c674986fe8d5cb873256b66 = L.marker(
                [34.06, -118.34],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_fb9f6d9d3d4ccedf5423b96ac742ed8d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_063b6c3a2c674986fe8d5cb873256b66.setIcon(icon_fb9f6d9d3d4ccedf5423b96ac742ed8d);


            var marker_654f06a46c49114af7b857b2b4b1b131 = L.marker(
                [34.14, -118.22],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0b50152ff7592313a2a3a2ab9602fac2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_654f06a46c49114af7b857b2b4b1b131.setIcon(icon_0b50152ff7592313a2a3a2ab9602fac2);


            var marker_76014282a28cac4f73901aab4e3fafc6 = L.marker(
                [34.02, -118.2],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_eda8b07cde8e694251bbfa4629ac3705 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_76014282a28cac4f73901aab4e3fafc6.setIcon(icon_eda8b07cde8e694251bbfa4629ac3705);


            var marker_8c8671f39e559261ddd5ba5574412398 = L.marker(
                [34.06, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0b666ea4fd6683bd3e978a799a3eb2bf = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8c8671f39e559261ddd5ba5574412398.setIcon(icon_0b666ea4fd6683bd3e978a799a3eb2bf);


            var marker_0834bf8bf1a659e7569df6b215b81e23 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f62101b8fddee310f000dd527d109cdc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0834bf8bf1a659e7569df6b215b81e23.setIcon(icon_f62101b8fddee310f000dd527d109cdc);


            var marker_57c98db7d4e5b0f9b27f5eeac61bc8df = L.marker(
                [34.06, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4fcbd110ae014559c3183972d74e4ed0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_57c98db7d4e5b0f9b27f5eeac61bc8df.setIcon(icon_4fcbd110ae014559c3183972d74e4ed0);


            var marker_f60ad2a398f705f3e397ddff0ebf2d2d = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_de672a49a3c3977b9d6c127c4fbdf155 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f60ad2a398f705f3e397ddff0ebf2d2d.setIcon(icon_de672a49a3c3977b9d6c127c4fbdf155);


            var marker_a79c396e6d27f44ffbd7d0dfa60a5566 = L.marker(
                [33.85, -118.31],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b5ce0eacd7cd1a9d7327b54f9d5e1225 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a79c396e6d27f44ffbd7d0dfa60a5566.setIcon(icon_b5ce0eacd7cd1a9d7327b54f9d5e1225);


            var marker_e2738c8042a610996fd5c5c6b01bfb24 = L.marker(
                [34.21, -118.56],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6a8b1b0dd680987995afda7f2a4fadb8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e2738c8042a610996fd5c5c6b01bfb24.setIcon(icon_6a8b1b0dd680987995afda7f2a4fadb8);


            var marker_41a1cfe62b81f7e737e70502d084cd44 = L.marker(
                [34.07, -118.22],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_092dd20eca8f4c18172f489f09f7729d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_41a1cfe62b81f7e737e70502d084cd44.setIcon(icon_092dd20eca8f4c18172f489f09f7729d);


            var marker_00e5a6acc9b546b548b56163bdf6dcd6 = L.marker(
                [34.1, -118.33],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f2c4747550b583d9b83c17a29cf54b15 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_00e5a6acc9b546b548b56163bdf6dcd6.setIcon(icon_f2c4747550b583d9b83c17a29cf54b15);


            var marker_f7ef1c6aa696f3a7445e35a67014e7e7 = L.marker(
                [33.78, -118.31],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_69f662bc112a7ccac08d52b6f276865d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f7ef1c6aa696f3a7445e35a67014e7e7.setIcon(icon_69f662bc112a7ccac08d52b6f276865d);


            var marker_3e1376a77b1786ae698ffd1afbee71ee = L.marker(
                [34.11, -118.19],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2a087922b42e91f41df67356e4205ef1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3e1376a77b1786ae698ffd1afbee71ee.setIcon(icon_2a087922b42e91f41df67356e4205ef1);


            var marker_cd330ca0968523ba1df7ab5a91e05f34 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b96869676ada0e3bc8334a847168ece0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cd330ca0968523ba1df7ab5a91e05f34.setIcon(icon_b96869676ada0e3bc8334a847168ece0);


            var marker_475fc912826e1600fee2a0a93a7b1114 = L.marker(
                [33.74, -118.29],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_aca021b46a6c7622af1bb7c4776404d5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_475fc912826e1600fee2a0a93a7b1114.setIcon(icon_aca021b46a6c7622af1bb7c4776404d5);


            var marker_2cd1d1cf8e19425b28d62242cf3610fb = L.marker(
                [33.98, -118.33],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c5295f1407f4e86c5016f77f7435ecc9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2cd1d1cf8e19425b28d62242cf3610fb.setIcon(icon_c5295f1407f4e86c5016f77f7435ecc9);


            var marker_d988a5fe772d0273e80bb2caf0b579bc = L.marker(
                [33.99, -118.31],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_76e2920f3eda957e0bffd0ea9bacea5c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d988a5fe772d0273e80bb2caf0b579bc.setIcon(icon_76e2920f3eda957e0bffd0ea9bacea5c);


            var marker_41ab7d01c63311725577d309024343c9 = L.marker(
                [34.11, -118.19],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_797a38b514d7eb3d0a6b4bee06b0e9eb = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_41ab7d01c63311725577d309024343c9.setIcon(icon_797a38b514d7eb3d0a6b4bee06b0e9eb);


            var marker_7d1c9e371fc900f01819ccfd53b65bf5 = L.marker(
                [34.09, -118.28],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9267f6aef11f77c60cce12d24b5b4d70 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7d1c9e371fc900f01819ccfd53b65bf5.setIcon(icon_9267f6aef11f77c60cce12d24b5b4d70);


            var marker_ce97f8dac7b0056201ec93650142f94e = L.marker(
                [33.99, -118.31],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4865ab8681310ed3bd30c1629aedaaf7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ce97f8dac7b0056201ec93650142f94e.setIcon(icon_4865ab8681310ed3bd30c1629aedaaf7);


            var marker_12842147243b42b9f74149b24efa3e9b = L.marker(
                [34.08, -118.44],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_99a05528e7f54768145443d84f6c467b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_12842147243b42b9f74149b24efa3e9b.setIcon(icon_99a05528e7f54768145443d84f6c467b);


            var marker_677c6379d7a6b84502292ca329254a7d = L.marker(
                [34.11, -118.22],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b1fd111d9c6d8a8b8f7d15f5a2f12005 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_677c6379d7a6b84502292ca329254a7d.setIcon(icon_b1fd111d9c6d8a8b8f7d15f5a2f12005);


            var marker_ff5ebbdc6dd793d951df0a4e2fd80cf4 = L.marker(
                [34.02, -118.35],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_56830da3870a80477ff61f9b966a640c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ff5ebbdc6dd793d951df0a4e2fd80cf4.setIcon(icon_56830da3870a80477ff61f9b966a640c);


            var marker_99c57a96d0fa49f8534bf2dcdb12cc8c = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a9233a10f29441fafdfd86c3ab12c528 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_99c57a96d0fa49f8534bf2dcdb12cc8c.setIcon(icon_a9233a10f29441fafdfd86c3ab12c528);


            var marker_312e83c02ac299422f82ab3ef2965d43 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ee514252e3e0a637bb77bed604aec763 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_312e83c02ac299422f82ab3ef2965d43.setIcon(icon_ee514252e3e0a637bb77bed604aec763);


            var marker_6b712e2ae976d0b9465523c8bce6d409 = L.marker(
                [34.14, -118.2],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_84145853a751410cfcda5e98c6a2d73e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6b712e2ae976d0b9465523c8bce6d409.setIcon(icon_84145853a751410cfcda5e98c6a2d73e);


            var marker_e34acc2bac9cdd3dd9de7289da53da1d = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e4ecf7e2ac0759a9841e641d7c85bd15 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e34acc2bac9cdd3dd9de7289da53da1d.setIcon(icon_e4ecf7e2ac0759a9841e641d7c85bd15);


            var marker_5696e322aad06e627aa134136fa64899 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7b4454b19b81390ef62e4ad2def67567 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5696e322aad06e627aa134136fa64899.setIcon(icon_7b4454b19b81390ef62e4ad2def67567);


            var marker_4d17af2823f73536e3243b01e0b95935 = L.marker(
                [33.74, -118.29],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d207e4fa10057bac9ec72fcbb40b61d2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4d17af2823f73536e3243b01e0b95935.setIcon(icon_d207e4fa10057bac9ec72fcbb40b61d2);


            var marker_bb644c0ffdcee1cdb06bb55264f30609 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_74fd26aab49e237e83e7e6d6e7a3f82f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_bb644c0ffdcee1cdb06bb55264f30609.setIcon(icon_74fd26aab49e237e83e7e6d6e7a3f82f);


            var marker_cdeddf0ad61e5904a021f90468a8f2f7 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_41347b74c4f1ad7762f89bdbfbbc560c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cdeddf0ad61e5904a021f90468a8f2f7.setIcon(icon_41347b74c4f1ad7762f89bdbfbbc560c);


            var marker_7849e66cf43067c3ced6d8f1e64f4af2 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6d069ba6aaf804d638006c01e9d16674 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7849e66cf43067c3ced6d8f1e64f4af2.setIcon(icon_6d069ba6aaf804d638006c01e9d16674);


            var marker_f3840b7759f016794dac563f8afc766d = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2c6ee3c405f50b461c323cff12fdfb15 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f3840b7759f016794dac563f8afc766d.setIcon(icon_2c6ee3c405f50b461c323cff12fdfb15);


            var marker_722857a0c6d2d4b9a471f1cd0ab8443f = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3cb45af7144e195b83bef9e34ba64eb4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_722857a0c6d2d4b9a471f1cd0ab8443f.setIcon(icon_3cb45af7144e195b83bef9e34ba64eb4);


            var marker_02a2af8e4d5b501e75fc571a59862943 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_94b851d57fe0206505355ecd5450fdfa = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_02a2af8e4d5b501e75fc571a59862943.setIcon(icon_94b851d57fe0206505355ecd5450fdfa);


            var marker_48f4aacfc554b03d377dbb984799d1ff = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_bef4e6315b7d526749a1f550ab0b78a9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_48f4aacfc554b03d377dbb984799d1ff.setIcon(icon_bef4e6315b7d526749a1f550ab0b78a9);


            var marker_a78a1a1f69d470d1b2aa6268f350b478 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0c49ed2dd813c533c0120e3af68efa79 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a78a1a1f69d470d1b2aa6268f350b478.setIcon(icon_0c49ed2dd813c533c0120e3af68efa79);


            var marker_eadc8e3d1f72bb89c2a6da663bdcc414 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1032a5700a775dac673ba88bc2ab9668 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_eadc8e3d1f72bb89c2a6da663bdcc414.setIcon(icon_1032a5700a775dac673ba88bc2ab9668);


            var marker_a5f7cc707d0b58c588c76647e3589f15 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f40c772401a006cec27f7a3f21aba7f0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a5f7cc707d0b58c588c76647e3589f15.setIcon(icon_f40c772401a006cec27f7a3f21aba7f0);


            var marker_b2461b3f54df604c6e065544b15385ea = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_22b5400288cb3b3ed0b858ddabd980d5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b2461b3f54df604c6e065544b15385ea.setIcon(icon_22b5400288cb3b3ed0b858ddabd980d5);


            var marker_65ffd762c99757877f7468084430f15e = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4687a4da83f1428075cbd37ad29c204b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_65ffd762c99757877f7468084430f15e.setIcon(icon_4687a4da83f1428075cbd37ad29c204b);


            var marker_f7801effebfcd6e05a4359e6fd39555f = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_34f6b9bb42dd50d490b0bdc0a31bf6eb = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f7801effebfcd6e05a4359e6fd39555f.setIcon(icon_34f6b9bb42dd50d490b0bdc0a31bf6eb);


            var marker_26858ee13ed72aee41834006d4beedf7 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4b266821bf4ae822a6d32998bd8bcedc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_26858ee13ed72aee41834006d4beedf7.setIcon(icon_4b266821bf4ae822a6d32998bd8bcedc);


            var marker_acebd03982ec14fd3fc8fe7e69d9c90b = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_dd82a166469c3de9f025a2940f65aaed = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_acebd03982ec14fd3fc8fe7e69d9c90b.setIcon(icon_dd82a166469c3de9f025a2940f65aaed);


            var marker_001ff760235cc1a076944c865704517d = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_7fad30c23cd1d7c5bc51ce6202d66bd2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_001ff760235cc1a076944c865704517d.setIcon(icon_7fad30c23cd1d7c5bc51ce6202d66bd2);


            var marker_721a3cc21e7ee19cc09fa93b9e8d7f49 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f60adddc0e1ceeac728e8e2ddc0f0443 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_721a3cc21e7ee19cc09fa93b9e8d7f49.setIcon(icon_f60adddc0e1ceeac728e8e2ddc0f0443);


            var marker_0950382143c848d28f409d36ae508239 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a35a9753234a6a6d4552be0d9c684d3e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0950382143c848d28f409d36ae508239.setIcon(icon_a35a9753234a6a6d4552be0d9c684d3e);


            var marker_9e5b66ed961443d83aa45a438f801687 = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6e1564780d6262ae5a315087170d20ef = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9e5b66ed961443d83aa45a438f801687.setIcon(icon_6e1564780d6262ae5a315087170d20ef);


            var marker_95ce8844be4dfd6f07dfa461e345981d = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6f8355600c4b93c7ea4e9c6b6848b709 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_95ce8844be4dfd6f07dfa461e345981d.setIcon(icon_6f8355600c4b93c7ea4e9c6b6848b709);


            var marker_878b0a38767b659fbd44d874a313364e = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_09c77f693a55ea9ba00091a9e85acac5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_878b0a38767b659fbd44d874a313364e.setIcon(icon_09c77f693a55ea9ba00091a9e85acac5);


            var marker_308f0c6999add375f40d3fbe8819690b = L.marker(
                [34.05, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_fb1a33bf5e76c62c8404a0ca06e34986 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_308f0c6999add375f40d3fbe8819690b.setIcon(icon_fb1a33bf5e76c62c8404a0ca06e34986);


            var marker_372b3979c0e1fac4c69b4f1ab5943726 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_23463ab0e57bac4124f4c0cbf09d242d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_372b3979c0e1fac4c69b4f1ab5943726.setIcon(icon_23463ab0e57bac4124f4c0cbf09d242d);


            var marker_28d84b974a05971fc927cd920dc9141d = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_750d3faceff9a85045eac53fea8fe4dd = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_28d84b974a05971fc927cd920dc9141d.setIcon(icon_750d3faceff9a85045eac53fea8fe4dd);


            var marker_606b6f326123cf222f3895c34494e1ce = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_23619551d08b95fa0fd1e29e65a7c02b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_606b6f326123cf222f3895c34494e1ce.setIcon(icon_23619551d08b95fa0fd1e29e65a7c02b);


            var marker_69dc721f09e930c6db5e691d1fd97284 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c108cc09096ba74b28afdc936e733d5d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_69dc721f09e930c6db5e691d1fd97284.setIcon(icon_c108cc09096ba74b28afdc936e733d5d);


            var marker_a5524619e1338ccd735ed7d8abb90393 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_14e3ecf717d9503b98b7df5abb5ea38f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a5524619e1338ccd735ed7d8abb90393.setIcon(icon_14e3ecf717d9503b98b7df5abb5ea38f);


            var marker_d63ba873adaac20cb5edf7849b0e00a2 = L.marker(
                [34.06, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_06d3d21dd6ffad014b473baea35b5714 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d63ba873adaac20cb5edf7849b0e00a2.setIcon(icon_06d3d21dd6ffad014b473baea35b5714);


            var marker_dc821fdbebcea4d17373ca25f330dc63 = L.marker(
                [34.05, -118.44],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_972e1adc3ee4a01f69c79e2569ec7592 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_dc821fdbebcea4d17373ca25f330dc63.setIcon(icon_972e1adc3ee4a01f69c79e2569ec7592);


            var marker_d17ec4571f1c4ab86c999e3b3fcf2f31 = L.marker(
                [34.09, -118.28],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_30f8c097201e4da728a4a80208bce478 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d17ec4571f1c4ab86c999e3b3fcf2f31.setIcon(icon_30f8c097201e4da728a4a80208bce478);


            var marker_befdc243c6affe181edee0ca72c3b666 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2d6a4a9c219f54b96bf3232d6226fc01 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_befdc243c6affe181edee0ca72c3b666.setIcon(icon_2d6a4a9c219f54b96bf3232d6226fc01);


            var marker_e457bc269980560b0889804784573f4d = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cd280b1da79ff1b82495060eae25fa0e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e457bc269980560b0889804784573f4d.setIcon(icon_cd280b1da79ff1b82495060eae25fa0e);


            var marker_85638570dcac466b696597fe0599709a = L.marker(
                [34.05, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_06b95e661d313b527ae23282256a9464 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_85638570dcac466b696597fe0599709a.setIcon(icon_06b95e661d313b527ae23282256a9464);


            var marker_668ba778cbc00aa35f244b85f4f6c5fc = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_bb5cccf1b5f9359b6c8c2c0c7b42e838 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_668ba778cbc00aa35f244b85f4f6c5fc.setIcon(icon_bb5cccf1b5f9359b6c8c2c0c7b42e838);


            var marker_6af63db243a8ad0c83a188e8b939dce9 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1e2173e4e3bd4f1370b537d9382f8a6c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6af63db243a8ad0c83a188e8b939dce9.setIcon(icon_1e2173e4e3bd4f1370b537d9382f8a6c);


            var marker_57bc914f0a35bd9808190199322496b1 = L.marker(
                [33.99, -118.31],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ba95b1c24f90fd58f29973236008ad6b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_57bc914f0a35bd9808190199322496b1.setIcon(icon_ba95b1c24f90fd58f29973236008ad6b);


            var marker_810158b6750fde2085e07b59bba2adeb = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9b0a3f6782f883d3205601f68646a2b2 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_810158b6750fde2085e07b59bba2adeb.setIcon(icon_9b0a3f6782f883d3205601f68646a2b2);


            var marker_7ccb8eaef7c8d1c819b6022a2090939b = L.marker(
                [34.06, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2c19ee0e20da2dcb7a992e88bbf60027 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7ccb8eaef7c8d1c819b6022a2090939b.setIcon(icon_2c19ee0e20da2dcb7a992e88bbf60027);


            var marker_52a222e13568253a3cc88feba53e0e73 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_bcb0023ff38d04f2f6e7f0dc09c07786 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_52a222e13568253a3cc88feba53e0e73.setIcon(icon_bcb0023ff38d04f2f6e7f0dc09c07786);


            var marker_a801403fcadfc88b4685cabd01836966 = L.marker(
                [34.06, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_46620c8ee9f3bf79e7207311bce5c0a3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a801403fcadfc88b4685cabd01836966.setIcon(icon_46620c8ee9f3bf79e7207311bce5c0a3);


            var marker_5c18a6df5aa5b3f36234047f87cc3f4a = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2a08bdc455cb7fd421f6fb34e33d6bee = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5c18a6df5aa5b3f36234047f87cc3f4a.setIcon(icon_2a08bdc455cb7fd421f6fb34e33d6bee);


            var marker_05563b4d2583b7d383239273b1f3de06 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ac9f50133a6c8d397db8135fe14256f9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_05563b4d2583b7d383239273b1f3de06.setIcon(icon_ac9f50133a6c8d397db8135fe14256f9);


            var marker_9bc9d686cef9ae9d9504612545a82261 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b8aa81dac37d9dc266b865f8c1985775 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9bc9d686cef9ae9d9504612545a82261.setIcon(icon_b8aa81dac37d9dc266b865f8c1985775);


            var marker_93c02c359a9961b0df618630487acde4 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4e659f2470e522ccad1d6add568653a5 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_93c02c359a9961b0df618630487acde4.setIcon(icon_4e659f2470e522ccad1d6add568653a5);


            var marker_7c1f6b8dbddd323ad5c67e6f8549f7ea = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_97360266b99c4f1026fc97f80d4a38fd = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7c1f6b8dbddd323ad5c67e6f8549f7ea.setIcon(icon_97360266b99c4f1026fc97f80d4a38fd);


            var marker_8ea99af29887453709f3c24c412165ee = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5d6048e61102500e9b1707fdbad8614d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8ea99af29887453709f3c24c412165ee.setIcon(icon_5d6048e61102500e9b1707fdbad8614d);


            var marker_d1b70bf8612020261ecf492be00f2b0d = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_76c7a1eb1003bbaffcdf4fb66e5b750e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d1b70bf8612020261ecf492be00f2b0d.setIcon(icon_76c7a1eb1003bbaffcdf4fb66e5b750e);


            var marker_c234b9f3078a3715f89f482a183cd92d = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c248681e017f2313d75c9c10fee1f73a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c234b9f3078a3715f89f482a183cd92d.setIcon(icon_c248681e017f2313d75c9c10fee1f73a);


            var marker_90c639dea5c286bb1631fe62978e2be2 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3a284db9e869a6f6f73aae89b38935a0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_90c639dea5c286bb1631fe62978e2be2.setIcon(icon_3a284db9e869a6f6f73aae89b38935a0);


            var marker_e97f1896b9a21c9541e8e672e67551f8 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_fbb9afb48fc00ba4047d2296d9e25603 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e97f1896b9a21c9541e8e672e67551f8.setIcon(icon_fbb9afb48fc00ba4047d2296d9e25603);


            var marker_f00839f4938e328a714d5c1ddce16d59 = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d1d03ee8ea8f1a84d3e94e4f692986cf = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f00839f4938e328a714d5c1ddce16d59.setIcon(icon_d1d03ee8ea8f1a84d3e94e4f692986cf);


            var marker_7372ee275926e055347692dc9b617e1a = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ddb96c458ad1bc16fb53d20c486d180c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7372ee275926e055347692dc9b617e1a.setIcon(icon_ddb96c458ad1bc16fb53d20c486d180c);


            var marker_6b0ffe121c33c853d61a7dfbf80cec57 = L.marker(
                [33.96, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_139b00447b5bda0f7b335e8272c836cc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_6b0ffe121c33c853d61a7dfbf80cec57.setIcon(icon_139b00447b5bda0f7b335e8272c836cc);


            var marker_d64e5050627da32bad7c4f475b5e6e9c = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6e53ba54e8a5f2854b159c5baca33e85 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d64e5050627da32bad7c4f475b5e6e9c.setIcon(icon_6e53ba54e8a5f2854b159c5baca33e85);


            var marker_aad519d05fb3e9ca6f6dfc3b02d3377d = L.marker(
                [34.05, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4ca6b4b4b9ab46f6a49701d19c1c8c04 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_aad519d05fb3e9ca6f6dfc3b02d3377d.setIcon(icon_4ca6b4b4b9ab46f6a49701d19c1c8c04);


            var marker_ddcdd01db39bd9b5a2f48cdbe3af45ea = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_fec92a22a43001e65526b2240a58d186 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ddcdd01db39bd9b5a2f48cdbe3af45ea.setIcon(icon_fec92a22a43001e65526b2240a58d186);


            var marker_9e665d80e317014a9f076e2f0556beb7 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6bf14c2c798cc0c78802edbf143fd510 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9e665d80e317014a9f076e2f0556beb7.setIcon(icon_6bf14c2c798cc0c78802edbf143fd510);


            var marker_3565133ecb766bcb187d7b62ed68f1d9 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_474015eeaa2bb9a4d65313df84972551 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3565133ecb766bcb187d7b62ed68f1d9.setIcon(icon_474015eeaa2bb9a4d65313df84972551);


            var marker_7ccaf0fee82a615521ba9af29e70d18d = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_961b51206693475c5824ace4e6a3b5e8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_7ccaf0fee82a615521ba9af29e70d18d.setIcon(icon_961b51206693475c5824ace4e6a3b5e8);


            var marker_5cab2a286ee60681642930f830158c2d = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_69e3693ffb9984d2553076cdc74f5e8d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5cab2a286ee60681642930f830158c2d.setIcon(icon_69e3693ffb9984d2553076cdc74f5e8d);


            var marker_3db9a90fb4fb4ca595108a93dd74b045 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_33e39fb63e0b9a91a98a3aaa203b701c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3db9a90fb4fb4ca595108a93dd74b045.setIcon(icon_33e39fb63e0b9a91a98a3aaa203b701c);


            var marker_73b80b1ccbcb888052d0077e6b2c8e1e = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cd121ea7a28a9f21372085243a3bf869 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_73b80b1ccbcb888052d0077e6b2c8e1e.setIcon(icon_cd121ea7a28a9f21372085243a3bf869);


            var marker_4afb47ed4427d8e9f6bffbd1c6e7118c = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ef8c5c0edc1b2aa5a18909acb4ed4d4d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4afb47ed4427d8e9f6bffbd1c6e7118c.setIcon(icon_ef8c5c0edc1b2aa5a18909acb4ed4d4d);


            var marker_0fc86eae45768b3fd89d32300d15f171 = L.marker(
                [34.09, -118.35],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0b36cded5bc3abe065eb794288130271 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0fc86eae45768b3fd89d32300d15f171.setIcon(icon_0b36cded5bc3abe065eb794288130271);


            var marker_15f7bd9fa06e4e52e10dc11884e67e47 = L.marker(
                [34.13, -118.2],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_492a4e9d1391016655b1a2e949620928 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_15f7bd9fa06e4e52e10dc11884e67e47.setIcon(icon_492a4e9d1391016655b1a2e949620928);


            var marker_9dff5bd4b88e65a5e3be40b666166d65 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_a95fc50899fb8f419152b4c9e0197eb3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9dff5bd4b88e65a5e3be40b666166d65.setIcon(icon_a95fc50899fb8f419152b4c9e0197eb3);


            var marker_fca3135f62ccf6185be3aae58f378251 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_51f9dcf550b234b4bb38c6784f416494 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_fca3135f62ccf6185be3aae58f378251.setIcon(icon_51f9dcf550b234b4bb38c6784f416494);


            var marker_d9d5e8373f49fff98c9b9519858eb236 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e7288246041e04648fb26e9a91ad9ade = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d9d5e8373f49fff98c9b9519858eb236.setIcon(icon_e7288246041e04648fb26e9a91ad9ade);


            var marker_5085fd9b63f62c6870f8d37e17296311 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f23ec28090fd8346813fe38430b30ebf = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5085fd9b63f62c6870f8d37e17296311.setIcon(icon_f23ec28090fd8346813fe38430b30ebf);


            var marker_10a431c4ec9c0cf8fbe120467edd914f = L.marker(
                [34.06, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_417ff08522a84413fc4319ae0f7ccc6f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_10a431c4ec9c0cf8fbe120467edd914f.setIcon(icon_417ff08522a84413fc4319ae0f7ccc6f);


            var marker_cc9a8b47fb11de225393996867275ac1 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4ebbdb7ae6a3e272b305d622e9025e0d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cc9a8b47fb11de225393996867275ac1.setIcon(icon_4ebbdb7ae6a3e272b305d622e9025e0d);


            var marker_633e26007b67b3c387c8afbb541f7c03 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8898ba87d09922b83ef5d0979e782d44 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_633e26007b67b3c387c8afbb541f7c03.setIcon(icon_8898ba87d09922b83ef5d0979e782d44);


            var marker_dea3e5db5ec8cd0ac7782b62634ce1e7 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_de8b7f2ca5e5d6b182bc03555fffc281 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_dea3e5db5ec8cd0ac7782b62634ce1e7.setIcon(icon_de8b7f2ca5e5d6b182bc03555fffc281);


            var marker_0096be9e112d9d85cbae126c977189d3 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f69023524398268f82596c9cc629906a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0096be9e112d9d85cbae126c977189d3.setIcon(icon_f69023524398268f82596c9cc629906a);


            var marker_bb1a486c849c971487b2e027ee79cc5e = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_de4c00a1abad896f6d12fc91447f626c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_bb1a486c849c971487b2e027ee79cc5e.setIcon(icon_de4c00a1abad896f6d12fc91447f626c);


            var marker_3bab7d3c23e2b3effaff4a85ac2dcd7f = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_5e818e66575600a7e04637dcd9d56f77 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3bab7d3c23e2b3effaff4a85ac2dcd7f.setIcon(icon_5e818e66575600a7e04637dcd9d56f77);


            var marker_3cfa1eab74f3048fd73164dc3747e49f = L.marker(
                [34.04, -118.27],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_099dc84702520b3c08b309400e92038b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3cfa1eab74f3048fd73164dc3747e49f.setIcon(icon_099dc84702520b3c08b309400e92038b);


            var marker_10cb9b2353035d5fcc615939d82ec48b = L.marker(
                [34.05, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_16f9a34af73ad1460fde9b384e1ec664 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_10cb9b2353035d5fcc615939d82ec48b.setIcon(icon_16f9a34af73ad1460fde9b384e1ec664);


            var marker_62f882bbb39f0a99dba3bcca5aab9008 = L.marker(
                [33.75, -118.3],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2cafaa63e1fc3e6a9f9c4714d63de78c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_62f882bbb39f0a99dba3bcca5aab9008.setIcon(icon_2cafaa63e1fc3e6a9f9c4714d63de78c);


            var marker_9c8ff7558f066a09eeb26052e84c4f97 = L.marker(
                [34.16, -118.44],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0541a776891fb198288a26b5d4a86174 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9c8ff7558f066a09eeb26052e84c4f97.setIcon(icon_0541a776891fb198288a26b5d4a86174);


            var marker_376a3005f36790ad4f56cb64a125373d = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_d4e7f108dd27e3f803e19ed28168b918 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_376a3005f36790ad4f56cb64a125373d.setIcon(icon_d4e7f108dd27e3f803e19ed28168b918);


            var marker_8cadc7e483482f7abb1de64749f60f18 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1170fbef805856b443a2f21054cd427c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_8cadc7e483482f7abb1de64749f60f18.setIcon(icon_1170fbef805856b443a2f21054cd427c);


            var marker_b094c4f2de62bb470ef545232d06c8ea = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_53f2937838b9b82ecda4d07ac7d30ee4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b094c4f2de62bb470ef545232d06c8ea.setIcon(icon_53f2937838b9b82ecda4d07ac7d30ee4);


            var marker_221c96345271c54e3d510213b255c021 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b5304c3bcc04f9cbd26db97a882ef652 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_221c96345271c54e3d510213b255c021.setIcon(icon_b5304c3bcc04f9cbd26db97a882ef652);


            var marker_67bcb06bb1b168a0444d399752ac0d8d = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6a18161826b0ebbb93a7981b3d0ef0e1 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_67bcb06bb1b168a0444d399752ac0d8d.setIcon(icon_6a18161826b0ebbb93a7981b3d0ef0e1);


            var marker_51ee7cd8f09364679c9dbe67285b05f0 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_2fff562f4b9cbdd9a8fe88d73c8db33e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_51ee7cd8f09364679c9dbe67285b05f0.setIcon(icon_2fff562f4b9cbdd9a8fe88d73c8db33e);


            var marker_2d0c1939e69825fdba0fc2ada285fc20 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3e44d99e3d865f41a36e98c9699d355a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2d0c1939e69825fdba0fc2ada285fc20.setIcon(icon_3e44d99e3d865f41a36e98c9699d355a);


            var marker_9e50dcdd490fa3a3b2b36a31215c05bd = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cbe6754d71334356ae6f2f76a3e40aca = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9e50dcdd490fa3a3b2b36a31215c05bd.setIcon(icon_cbe6754d71334356ae6f2f76a3e40aca);


            var marker_ddb045fcebd63d31006d743b51c70fbd = L.marker(
                [33.74, -118.29],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_8cd92cd298c8bfdd3a4c31b856b6945d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_ddb045fcebd63d31006d743b51c70fbd.setIcon(icon_8cd92cd298c8bfdd3a4c31b856b6945d);


            var marker_2cb568d7ca719b75f05a64c40a5c5591 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_180eec5c0df30440ba5020afe528b9c0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2cb568d7ca719b75f05a64c40a5c5591.setIcon(icon_180eec5c0df30440ba5020afe528b9c0);


            var marker_4a7eefaa9c36e048ee99ec6af9e06ed2 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_01773ba7889a3d75cc266a7a4e6d4845 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4a7eefaa9c36e048ee99ec6af9e06ed2.setIcon(icon_01773ba7889a3d75cc266a7a4e6d4845);


            var marker_f0506f5d13d3e7146e986f1bfc3267fb = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_96aa74b84ed20024b0eee869afb07a93 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_f0506f5d13d3e7146e986f1bfc3267fb.setIcon(icon_96aa74b84ed20024b0eee869afb07a93);


            var marker_c20d2f341121ee769ce9944febd82d95 = L.marker(
                [33.8, -118.3],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c46e40f66f63bce32c231b82be84a108 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_c20d2f341121ee769ce9944febd82d95.setIcon(icon_c46e40f66f63bce32c231b82be84a108);


            var marker_4572523e1d29a34577434bb36799d5ac = L.marker(
                [34.04, -118.4],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_817c48fd968a8d763089f064ef1ade3c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_4572523e1d29a34577434bb36799d5ac.setIcon(icon_817c48fd968a8d763089f064ef1ade3c);


            var marker_2011c1efdbb35e4c45c00588c12958d3 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_9a8355729588c0f6d3d3c49d261c318b = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2011c1efdbb35e4c45c00588c12958d3.setIcon(icon_9a8355729588c0f6d3d3c49d261c318b);


            var marker_5088567e05c9b02219ad1e577767bd34 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_06939444f56f025c092465aab20949a3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_5088567e05c9b02219ad1e577767bd34.setIcon(icon_06939444f56f025c092465aab20949a3);


            var marker_2295cc23212c86bcb52062a4f161e037 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ca9b05dd9f1d88b9c436f32bc153df2e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2295cc23212c86bcb52062a4f161e037.setIcon(icon_ca9b05dd9f1d88b9c436f32bc153df2e);


            var marker_b0a80b0c60b1f0a5d8b1db20505fbf22 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_1d7a3be7f1c2ca6382cb97847d4fc643 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b0a80b0c60b1f0a5d8b1db20505fbf22.setIcon(icon_1d7a3be7f1c2ca6382cb97847d4fc643);


            var marker_eb372bc33fde326555751dd9a5c09acf = L.marker(
                [34.07, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c6b0d890b091db386452e956e324b0c0 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_eb372bc33fde326555751dd9a5c09acf.setIcon(icon_c6b0d890b091db386452e956e324b0c0);


            var marker_b5e67412527d2521fed81e800d6e5c16 = L.marker(
                [34.04, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e0c524b3a283afd4db238c4ad52507de = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b5e67412527d2521fed81e800d6e5c16.setIcon(icon_e0c524b3a283afd4db238c4ad52507de);


            var marker_0c80f07d58886d012e7e8e6ce68d61d2 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_825653429dd6c19ea808eeea50c92459 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0c80f07d58886d012e7e8e6ce68d61d2.setIcon(icon_825653429dd6c19ea808eeea50c92459);


            var marker_3440dc72023fcc256a1978a472b5963f = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_07e1197c1b4270af47c6b997963bb6bb = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3440dc72023fcc256a1978a472b5963f.setIcon(icon_07e1197c1b4270af47c6b997963bb6bb);


            var marker_e5480c60197e3bb55509150367b1512f = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_12997559cb7fee831ec48ef6b21b7e56 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e5480c60197e3bb55509150367b1512f.setIcon(icon_12997559cb7fee831ec48ef6b21b7e56);


            var marker_885c7236959480649deb60977988421c = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e13f1ee7899786a09ac42e18b0851a45 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_885c7236959480649deb60977988421c.setIcon(icon_e13f1ee7899786a09ac42e18b0851a45);


            var marker_05da7cd8a7de43d3c7bfcad31659a43a = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c0b1deab66443f4903f77ed2d978b045 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_05da7cd8a7de43d3c7bfcad31659a43a.setIcon(icon_c0b1deab66443f4903f77ed2d978b045);


            var marker_a8b68b4987bc6d30b13b75081ad24b21 = L.marker(
                [34.04, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_42fa4e35d72a8ec2c87d3b66f84b421c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a8b68b4987bc6d30b13b75081ad24b21.setIcon(icon_42fa4e35d72a8ec2c87d3b66f84b421c);


            var marker_70c3add528bcb11a54b818c7f41af1a0 = L.marker(
                [34.07, -118.37],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3a0df06154558cad0a28f1733b19c246 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_70c3add528bcb11a54b818c7f41af1a0.setIcon(icon_3a0df06154558cad0a28f1733b19c246);


            var marker_d7975db2730789fb74576007e0c28a7f = L.marker(
                [34.07, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_426e90dc638cd0304b12d68f99999785 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_d7975db2730789fb74576007e0c28a7f.setIcon(icon_426e90dc638cd0304b12d68f99999785);


            var marker_835dc46b70299035143f0ac267316a11 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cffb707998c6b0c95771d842bd904b70 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_835dc46b70299035143f0ac267316a11.setIcon(icon_cffb707998c6b0c95771d842bd904b70);


            var marker_06a7b35ee8fdf6da12619f6c888106be = L.marker(
                [34.11, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_ea388bf3efd5d30c2f3dff9b91a3d329 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_06a7b35ee8fdf6da12619f6c888106be.setIcon(icon_ea388bf3efd5d30c2f3dff9b91a3d329);


            var marker_3a4b700c5bbc1a9a494327e0377b87da = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_56579f4f1945fe64012fa0a38ce5fad7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_3a4b700c5bbc1a9a494327e0377b87da.setIcon(icon_56579f4f1945fe64012fa0a38ce5fad7);


            var marker_793151127a36dbff36cac1edb4b3ee05 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0f8d272bd94e182e29d2dcfb1d8e880f = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_793151127a36dbff36cac1edb4b3ee05.setIcon(icon_0f8d272bd94e182e29d2dcfb1d8e880f);


            var marker_2dbea30a8b126b5055ca37490fda1172 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_f5bd781c0f9908a2221dace504477a06 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2dbea30a8b126b5055ca37490fda1172.setIcon(icon_f5bd781c0f9908a2221dace504477a06);


            var marker_274a00c897b8dfd5a5e46fe014920ab1 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_cb229e3996d746ae090d01a9e1831a31 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_274a00c897b8dfd5a5e46fe014920ab1.setIcon(icon_cb229e3996d746ae090d01a9e1831a31);


            var marker_45db1cbf8baf7d14175aa8f1cb178335 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0f59f9549ef55542dae78feaa7c584bc = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_45db1cbf8baf7d14175aa8f1cb178335.setIcon(icon_0f59f9549ef55542dae78feaa7c584bc);


            var marker_cdc558dca6331f8adbeaa4b2effaa840 = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_803c49b097014a7a14d640ff4fec2f19 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cdc558dca6331f8adbeaa4b2effaa840.setIcon(icon_803c49b097014a7a14d640ff4fec2f19);


            var marker_1e99aa21a87e6eb0a2f8bd3f3e1ec9b6 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_3147ba53d3cdd3f3fd7fc1a45d0ceefd = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_1e99aa21a87e6eb0a2f8bd3f3e1ec9b6.setIcon(icon_3147ba53d3cdd3f3fd7fc1a45d0ceefd);


            var marker_98d16017c346429140dcdd599446cb7e = L.marker(
                [34.07, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_07986f548e0abb6cdd01b9e0c54e04e8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_98d16017c346429140dcdd599446cb7e.setIcon(icon_07986f548e0abb6cdd01b9e0c54e04e8);


            var marker_9286b5b9dafdd36c03248ccf053bd7f6 = L.marker(
                [34.08, -118.35],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_43e7583d9ebacbc15752b0d0c3b4e7f8 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_9286b5b9dafdd36c03248ccf053bd7f6.setIcon(icon_43e7583d9ebacbc15752b0d0c3b4e7f8);


            var marker_b460947cebd91856b26db8336ebd1992 = L.marker(
                [34.1, -118.3],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_020d7b2849963eb1feedf956b4885c00 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b460947cebd91856b26db8336ebd1992.setIcon(icon_020d7b2849963eb1feedf956b4885c00);


            var marker_da6f3966c210774cddd1fafd3a6861ba = L.marker(
                [34.07, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_38da34da52bf526f5408e70a9b3e7b83 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_da6f3966c210774cddd1fafd3a6861ba.setIcon(icon_38da34da52bf526f5408e70a9b3e7b83);


            var marker_70c70f94548093053b88f850310522bf = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_551e8ba56a50e0406b1abf2a21c41147 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_70c70f94548093053b88f850310522bf.setIcon(icon_551e8ba56a50e0406b1abf2a21c41147);


            var marker_e864607d39381eb551e8e047014e9cf5 = L.marker(
                [34.14, -118.23],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c35bb8858357fe84b554977dd4b23ea9 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e864607d39381eb551e8e047014e9cf5.setIcon(icon_c35bb8858357fe84b554977dd4b23ea9);


            var marker_cbbefa62d7831bb711b2e1ec323d6296 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b2c95d1f6d754b0f8359db2ab12a301a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_cbbefa62d7831bb711b2e1ec323d6296.setIcon(icon_b2c95d1f6d754b0f8359db2ab12a301a);


            var marker_09b6c44792091e8367d1cfe04208e234 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e85f76c57ac1586055fdc2c35c87233a = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_09b6c44792091e8367d1cfe04208e234.setIcon(icon_e85f76c57ac1586055fdc2c35c87233a);


            var marker_a47cb5c79cc2a1458787d3420b87f106 = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_610badb15edb48de96a6f0a9e92ed9e4 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_a47cb5c79cc2a1458787d3420b87f106.setIcon(icon_610badb15edb48de96a6f0a9e92ed9e4);


            var marker_02f2db091d1a8690cd4d615f9ee9044e = L.marker(
                [34.06, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_e6c8470e2cf35739781a80406a2d5d96 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_02f2db091d1a8690cd4d615f9ee9044e.setIcon(icon_e6c8470e2cf35739781a80406a2d5d96);


            var marker_0ffb9a5f3621e0af33c9a821738be31b = L.marker(
                [34.04, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_6ba57810305e8552142f5987d45a8f5d = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0ffb9a5f3621e0af33c9a821738be31b.setIcon(icon_6ba57810305e8552142f5987d45a8f5d);


            var marker_2902e107fce61452eb623ad1662906a8 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_94ebd6771c2a2c560a5ee974a5febf34 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_2902e107fce61452eb623ad1662906a8.setIcon(icon_94ebd6771c2a2c560a5ee974a5febf34);


            var marker_519f8b7139a56d10adb5c3b312f97f83 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_48e1378e0aa2e0faf16e82110263e417 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_519f8b7139a56d10adb5c3b312f97f83.setIcon(icon_48e1378e0aa2e0faf16e82110263e417);


            var marker_0efdc2188f1d2083daf2bf9bad3954a3 = L.marker(
                [34.05, -118.26],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_b8c707d03451f9a24ae0a6a0ea7d82a3 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_0efdc2188f1d2083daf2bf9bad3954a3.setIcon(icon_b8c707d03451f9a24ae0a6a0ea7d82a3);


            var marker_b224b11a9e5d3e1129f8f8654d026910 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_4518975e79aae50208b6133fb8e1be9c = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_b224b11a9e5d3e1129f8f8654d026910.setIcon(icon_4518975e79aae50208b6133fb8e1be9c);


            var marker_60db8620a6385d0956a69a6997f696d5 = L.marker(
                [34.05, -118.25],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_0aa969e7b1cfeea49d0014dbaa4595c7 = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_60db8620a6385d0956a69a6997f696d5.setIcon(icon_0aa969e7b1cfeea49d0014dbaa4595c7);


            var marker_e00ca60cc2158269ccd755dd0567ab5d = L.marker(
                [34.05, -118.24],
                {}
            ).addTo(map_e02899f4f20b3725efe51d91e237c586);


            var icon_c8467a677ea496ca3efa4ec38326314e = L.AwesomeMarkers.icon(
                {&quot;extraClasses&quot;: &quot;fa-rotate-0&quot;, &quot;icon&quot;: &quot;info-sign&quot;, &quot;iconColor&quot;: &quot;white&quot;, &quot;markerColor&quot;: &quot;red&quot;, &quot;prefix&quot;: &quot;glyphicon&quot;}
            );
            marker_e00ca60cc2158269ccd755dd0567ab5d.setIcon(icon_c8467a677ea496ca3efa4ec38326314e);

&lt;/script&gt;
&lt;/html&gt;" style="position:absolute;width:100%;height:100%;left:0;top:0;border:none !important;" allowfullscreen webkitallowfullscreen mozallowfullscreen></iframe></div></div>





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LAT</th>
      <th>LON</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>34.01</td>
      <td>-118.30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>34.05</td>
      <td>-118.25</td>
    </tr>
    <tr>
      <th>2</th>
      <td>34.17</td>
      <td>-118.40</td>
    </tr>
    <tr>
      <th>3</th>
      <td>34.22</td>
      <td>-118.45</td>
    </tr>
    <tr>
      <th>4</th>
      <td>34.05</td>
      <td>-118.26</td>
    </tr>
    <tr>
      <th>5</th>
      <td>34.04</td>
      <td>-118.25</td>
    </tr>
    <tr>
      <th>6</th>
      <td>34.07</td>
      <td>-118.24</td>
    </tr>
    <tr>
      <th>7</th>
      <td>34.04</td>
      <td>-118.26</td>
    </tr>
    <tr>
      <th>8</th>
      <td>34.06</td>
      <td>-118.24</td>
    </tr>
    <tr>
      <th>9</th>
      <td>34.05</td>
      <td>-118.26</td>
    </tr>
  </tbody>
</table>
</div>



# Victim Demographics


```python
query = "SELECT Vict_Age as victim_age, Vict_Sex as victim_sex FROM crimedata;"
df = pd.read_sql(query, connection)
plt.figure(figsize=(10, 6))
df['victim_age'].dropna().hist(bins=30)
plt.title('Distribution of Victim Ages')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# Plot distribution of victim genders
plt.figure(figsize=(6, 6))
df['victim_sex'].dropna().value_counts().plot(kind='bar')
plt.title('Distribution of Victim Genders')
plt.xlabel('Gender')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

```


    
![png](output_12_0.png)
    



    
![png](output_12_1.png)
    


# Status Analysis


```python
colors = plt.cm.viridis(np.linspace(0, 1, df.shape[0]))
plt.figure(figsize=(12, 6))
plt.bar(df['status'], df['count'], color=colors)
plt.title('Crime Status Distribution', fontsize=16, fontweight='bold')
plt.xlabel('Status', fontsize=12)
plt.ylabel('Number of Crimes', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.gca().spines['top'].set_visible(False)
plt.gca().spines['right'].set_visible(False)
plt.tight_layout()
plt.show()
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    File ~\anaconda3\Lib\site-packages\pandas\core\indexes\base.py:3791, in Index.get_loc(self, key)
       3790 try:
    -> 3791     return self._engine.get_loc(casted_key)
       3792 except KeyError as err:
    

    File index.pyx:152, in pandas._libs.index.IndexEngine.get_loc()
    

    File index.pyx:181, in pandas._libs.index.IndexEngine.get_loc()
    

    File pandas\_libs\hashtable_class_helper.pxi:7080, in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    File pandas\_libs\hashtable_class_helper.pxi:7088, in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: 'status'

    
    The above exception was the direct cause of the following exception:
    

    KeyError                                  Traceback (most recent call last)

    Cell In[56], line 3
          1 colors = plt.cm.viridis(np.linspace(0, 1, df.shape[0]))
          2 plt.figure(figsize=(12, 6))
    ----> 3 plt.bar(df['status'], df['count'], color=colors)
          4 plt.title('Crime Status Distribution', fontsize=16, fontweight='bold')
          5 plt.xlabel('Status', fontsize=12)
    

    File ~\anaconda3\Lib\site-packages\pandas\core\frame.py:3893, in DataFrame.__getitem__(self, key)
       3891 if self.columns.nlevels > 1:
       3892     return self._getitem_multilevel(key)
    -> 3893 indexer = self.columns.get_loc(key)
       3894 if is_integer(indexer):
       3895     indexer = [indexer]
    

    File ~\anaconda3\Lib\site-packages\pandas\core\indexes\base.py:3798, in Index.get_loc(self, key)
       3793     if isinstance(casted_key, slice) or (
       3794         isinstance(casted_key, abc.Iterable)
       3795         and any(isinstance(x, slice) for x in casted_key)
       3796     ):
       3797         raise InvalidIndexError(key)
    -> 3798     raise KeyError(key) from err
       3799 except TypeError:
       3800     # If we have a listlike key, _check_indexing_error will raise
       3801     #  InvalidIndexError. Otherwise we fall through and re-raise
       3802     #  the TypeError.
       3803     self._check_indexing_error(key)
    

    KeyError: 'status'



    <Figure size 1200x600 with 0 Axes>


#  Crime Code Analysis


```python


query = "SELECT Crm_Cd as crime_code, Crm_Cd_Desc as crime_code_description, COUNT(*) AS crime_count FROM crimedata GROUP BY Crm_Cd, Crm_Cd_Desc;"

df = pd.read_sql(query, connection)
print(df)
plt.figure(figsize=(14, 8))
top_crime_codes = df.head(20)
plt.bar(top_crime_codes['crime_code_description'], top_crime_codes['crime_count'], color='skyblue')
plt.title('Top 20 Crime Codes by Frequency', fontsize=16, fontweight='bold')
plt.xlabel('Crime Code Description', fontsize=12)
plt.ylabel('Number of Crimes', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.gca().spines['top'].set_visible(False)
plt.gca().spines['right'].set_visible(False)
plt.tight_layout()
plt.show()


```

        crime_code                             crime_code_description  crime_count
    0          624                           BATTERY - SIMPLE ASSAULT           74
    1          745           VANDALISM - MISDEAMEANOR ($399 OR UNDER)           23
    2          740  VANDALISM - FELONY ($400 & OVER, ALL CHURCH VA...           23
    3          442           SHOPLIFTING - PETTY THEFT ($950 & UNDER)           28
    4          946                          OTHER MISCELLANEOUS CRIME            4
    5          341  THEFT-GRAND ($950.01 & OVER)EXCPT,GUNS,FOWL,LI...           26
    6          330                              BURGLARY FROM VEHICLE           82
    7          930             CRIMINAL THREATS - NO WEAPON DISPLAYED            7
    8          648                                              ARSON            3
    9          354                                  THEFT OF IDENTITY           10
    10         230     ASSAULT WITH DEADLY WEAPON, AGGRAVATED ASSAULT           24
    11         761                                    BRANDISH WEAPON            5
    12         350                                      THEFT, PERSON            9
    13         310                                           BURGLARY           16
    14         480                                      BIKE - STOLEN           11
    15         623                            BATTERY POLICE (SIMPLE)            5
    16         440                 THEFT PLAIN - PETTY ($950 & UNDER)           44
    17         510                                   VEHICLE - STOLEN           28
    18         210                                            ROBBERY           12
    19         900                           VIOLATION OF COURT ORDER            2
    20         888                                        TRESPASSING           19
    21         420    THEFT FROM MOTOR VEHICLE - PETTY ($950 & UNDER)            9
    22         886                               DISTURBING THE PEACE            2
    23         421                 THEFT FROM MOTOR VEHICLE - ATTEMPT            1
    24         647                  THROWING OBJECT AT MOVING VEHICLE            1
    25         940                                          EXTORTION            1
    26         662                                 BUNCO, GRAND THEFT            5
    27         220                                  ATTEMPTED ROBBERY            4
    28         625                                      OTHER ASSAULT            2
    29         755                                         BOMB SCARE            1
    30         649                   DOCUMENT FORGERY / STOLEN FELONY            1
    31         901                     VIOLATION OF RESTRAINING ORDER            3
    32         320                                BURGLARY, ATTEMPTED            2
    33         890                                   FAILURE TO YIELD            1
    34         351                                    PURSE SNATCHING            2
    35         956            LETTERS, LEWD  -  TELEPHONE CALLS, LEWD            2
    36         820                                    ORAL COPULATION            1
    37         812  CRM AGNST CHLD (13 OR UNDER) (14-15 & SUSP 10 ...            1
    38         920                         KIDNAPPING - GRAND ATTEMPT            1
    39         850                                  INDECENT EXPOSURE            2
    40         666                                     BUNCO, ATTEMPT            1
    41         343           SHOPLIFTING-GRAND THEFT ($950.01 & OVER)            1
    


    
![png](output_16_1.png)
    



```python

```


```python

```
